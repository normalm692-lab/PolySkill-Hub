import { ArrowRight, CheckCircle2, Star, Briefcase, ExternalLink } from 'lucide-react';
import { JobItem, Language, PlatformStats, ProjectItem, UserProfile } from '../types';
import { PageView } from './Header';
import { ProjectCard } from './ProjectCard';
import { SmartImage } from './SmartImage';
import { t } from '../i18n';

interface HomeViewProps {
  lang: Language;
  stats: PlatformStats;
  projects: ProjectItem[];
  students: UserProfile[];
  jobs: JobItem[];
  currentUser: UserProfile | null;
  onNavigate: (page: PageView) => void;
  onViewProject: (project: ProjectItem) => void;
  onSelectStudent: (userId: number) => void;
  onOpenUpload: () => void;
  onApplyJob: (job: JobItem) => void;
}

export function HomeView({
  lang,
  stats,
  projects,
  students,
  jobs,
  currentUser,
  onNavigate,
  onViewProject,
  onSelectStudent,
  onOpenUpload,
  onApplyJob,
}: HomeViewProps) {
  const featuredProjects = projects.slice(0, 6);
  const topStudents = students.slice(0, 6);
  const recentJobs = jobs.slice(0, 4);

  return (
    <div className="space-y-16 pb-16">
      {/* Asymmetric 2-Column Hero Split */}
      <section className="pt-8 sm:pt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
            {/* Left Column: Typographic Hierarchy */}
            <div className="lg:col-span-6 flex flex-col justify-center py-2">
              <p className="text-xs font-semibold tracking-wide text-blue-600 dark:text-blue-400 mb-3">
                {t(lang, 'campusTag')} <span aria-hidden="true">·</span> {t(lang, 'slogan')}
              </p>

              <h1
                className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-[1.15] mb-5"
                style={{ textWrap: 'balance' }}
              >
                {t(lang, 'heroTitle')}
              </h1>

              <p className="text-base text-slate-600 dark:text-slate-300 leading-relaxed max-w-xl mb-8">
                {t(lang, 'heroSubtitle')}
              </p>

              <div className="flex flex-wrap items-center gap-4">
                <button
                  type="button"
                  onClick={() => onNavigate('projects')}
                  className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                >
                  <span>{t(lang, 'exploreProjects')}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={currentUser ? onOpenUpload : () => onNavigate('auth')}
                  className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:border-blue-400 dark:hover:border-blue-500 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                >
                  {currentUser ? t(lang, 'uploadProject') : t(lang, 'joinPlatform')}
                </button>
              </div>
            </div>

            {/* Right Column: Matching Height Visual Container */}
            <div className="lg:col-span-6">
              <div className="h-72 sm:h-96 lg:h-full min-h-[340px] rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900">
                <SmartImage
                  src="/src/assets/images/hero_poly_campus_1794537258602.jpg"
                  alt="Naogaon Polytechnic engineering students collaborating on laptops, circuits, and blueprints"
                  fallbackTitle="Naogaon Polytechnic Innovation Studio"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>

          {/* 4-Column Stats Row directly below hero split */}
          <div className="mt-10 grid grid-cols-2 lg:grid-cols-4 gap-4 border-y border-slate-200 dark:border-slate-800 py-6">
            <div className="px-2">
              <p className="text-2xl sm:text-3xl font-extrabold font-mono tabular-nums text-slate-900 dark:text-white">
                {stats.total_projects}
              </p>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
                {t(lang, 'statProjects')}
              </p>
            </div>
            <div className="px-2">
              <p className="text-2xl sm:text-3xl font-extrabold font-mono tabular-nums text-slate-900 dark:text-white">
                {stats.total_students}
              </p>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
                {t(lang, 'statStudents')}
              </p>
            </div>
            <div className="px-2">
              <p className="text-2xl sm:text-3xl font-extrabold font-mono tabular-nums text-emerald-600 dark:text-emerald-400">
                {stats.total_mentors}
              </p>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
                {t(lang, 'statMentors')}
              </p>
            </div>
            <div className="px-2">
              <p className="text-2xl sm:text-3xl font-extrabold font-mono tabular-nums text-blue-600 dark:text-blue-400">
                {stats.open_jobs}
              </p>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
                {t(lang, 'statJobs')}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Department Projects */}
      <section>
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
            <div>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
                {t(lang, 'featuredProjectsTitle')}
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-400 mt-1.5">
                {t(lang, 'featuredProjectsSub')}
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('projects')}
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-blue-600 dark:text-blue-400 hover:underline whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>{t(lang, 'viewAllProjects')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredProjects.map((project) => (
              <ProjectCard
                key={project.id}
                project={project}
                lang={lang}
                onViewProject={onViewProject}
                onContactStudent={onSelectStudent}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Top Skilled Students & Mentors (3-column clean grid) */}
      <section className="py-12 bg-white dark:bg-slate-900/50 border-y border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
            <div>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
                {t(lang, 'topStudentsTitle')}
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-400 mt-1.5">
                {t(lang, 'topStudentsSub')}
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('mentors')}
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-blue-600 dark:text-blue-400 hover:underline whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>{t(lang, 'navMentors')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {topStudents.map((student) => (
              <div
                key={student.id}
                onClick={() => onSelectStudent(student.id)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    onSelectStudent(student.id);
                  }
                }}
                className="flex flex-col p-5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl hover:border-blue-400 dark:hover:border-blue-600 transition-colors cursor-pointer text-left"
              >
                <div className="flex items-start gap-4 mb-3">
                  <SmartImage
                    src={student.photo}
                    alt={student.name}
                    className="w-16 h-16 rounded-xl object-cover shrink-0 border border-slate-200 dark:border-slate-700"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <h3 className="text-base font-bold text-slate-900 dark:text-white truncate">
                        {student.name}
                      </h3>
                      {student.is_verified === 1 && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                      )}
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                      {student.department} · {student.semester} Sem
                      {student.roll_no ? ` · Roll ${student.roll_no}` : ''}
                    </p>
                    <p className="text-xs font-medium text-emerald-700 dark:text-emerald-400 mt-1">
                      {student.role === 'mentor'
                        ? lang === 'bn'
                          ? 'সিনিয়র মেন্টর'
                          : 'Senior Mentor'
                        : lang === 'bn'
                          ? 'শিক্ষার্থী'
                          : 'Student'}
                    </p>
                  </div>
                </div>

                <p className="text-sm text-slate-600 dark:text-slate-400 line-clamp-2 mb-3">
                  {student.bio}
                </p>

                <div className="mt-auto pt-3 border-t border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-2 text-xs">
                  <span className="text-slate-500 dark:text-slate-400 truncate">
                    {student.skills.slice(0, 4).join(' · ') || 'Polytechnic Student'}
                  </span>
                  <span className="inline-flex items-center gap-1 font-mono tabular-nums text-slate-700 dark:text-slate-300 shrink-0">
                    <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                    {student.avg_rating > 0 ? student.avg_rating.toFixed(1) : '—'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Local Naogaon Micro-Jobs Preview */}
      <section>
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
            <div>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
                {t(lang, 'localJobsTitle')}
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-400 mt-1.5">
                {t(lang, 'localJobsSub')}
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('jobs')}
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-blue-600 dark:text-blue-400 hover:underline whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>{t(lang, 'viewAllJobs')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {recentJobs.map((job) => {
              const jTitle = lang === 'bn' && job.title_bn ? job.title_bn : job.title;
              return (
                <div
                  key={job.id}
                  className="flex flex-col p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl"
                >
                  <div className="flex items-start justify-between gap-4 mb-2">
                    <div className="min-w-0">
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {job.client_name} · {job.department}
                      </p>
                      <h3 className="text-base font-bold text-slate-900 dark:text-white mt-0.5">
                        {jTitle}
                      </h3>
                    </div>
                    <span className="font-mono tabular-nums text-sm font-bold text-emerald-700 dark:text-emerald-400 shrink-0">
                      {job.budget}
                    </span>
                  </div>

                  <p className="text-sm text-slate-600 dark:text-slate-400 line-clamp-2 mb-4">
                    {job.description}
                  </p>

                  <div className="mt-auto pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
                    <span className="inline-flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400 truncate">
                      <Briefcase className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 shrink-0" />
                      {job.contact}
                    </span>
                    <button
                      type="button"
                      onClick={() => onApplyJob(job)}
                      className="inline-flex items-center gap-1 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <span>{t(lang, 'applyNow')}</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}
