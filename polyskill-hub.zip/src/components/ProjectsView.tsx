import { useMemo, useState } from 'react';
import { Search, Plus, RotateCcw } from 'lucide-react';
import { Language, ProjectItem } from '../types';
import { DEPARTMENTS, t } from '../i18n';
import { ProjectCard } from './ProjectCard';

interface ProjectsViewProps {
  lang: Language;
  projects: ProjectItem[];
  availableSkills: string[];
  onViewProject: (project: ProjectItem) => void;
  onContactStudent: (userId: number) => void;
  onOpenUpload: () => void;
}

export function ProjectsView({
  lang,
  projects,
  availableSkills,
  onViewProject,
  onContactStudent,
  onOpenUpload,
}: ProjectsViewProps) {
  const [selectedDept, setSelectedDept] = useState<string>('all');
  const [selectedSkill, setSelectedSkill] = useState<string>('all');
  const [query, setQuery] = useState('');

  const topSkills = useMemo(() => {
    const preferred = ['HTML', 'CSS', 'JavaScript', 'PHP', 'Laravel', 'React', 'Python', 'AutoCAD', 'PLC'];
    const merged = Array.from(new Set([...preferred, ...availableSkills]));
    return merged.slice(0, 12);
  }, [availableSkills]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return projects.filter((p) => {
      if (selectedDept !== 'all' && p.department !== selectedDept) return false;
      if (selectedSkill !== 'all' && !p.tags.some((tag) => tag.toLowerCase() === selectedSkill.toLowerCase())) {
        return false;
      }
      if (q) {
        const hay = `${p.title} ${p.title_bn} ${p.description} ${p.author_name} ${p.tags.join(' ')}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [projects, selectedDept, selectedSkill, query]);

  const resetFilters = () => {
    setSelectedDept('all');
    setSelectedSkill('all');
    setQuery('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
            {t(lang, 'navProjects')}
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            {t(lang, 'featuredProjectsSub')}
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenUpload}
          className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{t(lang, 'uploadProject')}</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="space-y-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 sm:p-5">
        <div className="flex flex-col lg:flex-row lg:items-center gap-4 justify-between">
          {/* Search Input */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t(lang, 'searchProjectsPlaceholder')}
              className="w-full pl-10 pr-4 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Department Segmented Buttons */}
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={() => setSelectedDept('all')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                selectedDept === 'all'
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {t(lang, 'allDepartments')}
            </button>
            {DEPARTMENTS.map((dept) => (
              <button
                key={dept}
                type="button"
                onClick={() => setSelectedDept(dept)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  selectedDept === dept
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                {dept}
              </button>
            ))}
          </div>
        </div>

        {/* Skill Tag Interactive Buttons */}
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-1.5">
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400 mr-1">
            {lang === 'bn' ? 'স্কিল:' : 'Skills:'}
          </span>
          <button
            type="button"
            onClick={() => setSelectedSkill('all')}
            className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              selectedSkill === 'all'
                ? 'bg-emerald-600 text-white'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            {t(lang, 'allSkills')}
          </button>
          {topSkills.map((skill) => (
            <button
              key={skill}
              type="button"
              onClick={() => setSelectedSkill(selectedSkill === skill ? 'all' : skill)}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                selectedSkill === skill
                  ? 'bg-emerald-600 text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {skill}
            </button>
          ))}
        </div>
      </div>

      {/* Results Count */}
      <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
        <span className="font-mono tabular-nums">
          {filtered.length} {lang === 'bn' ? 'টি প্রজেক্ট পাওয়া গেছে' : 'projects shown'}
        </span>
        {(selectedDept !== 'all' || selectedSkill !== 'all' || query) && (
          <button
            type="button"
            onClick={resetFilters}
            className="inline-flex items-center gap-1 text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t(lang, 'clearFilters')}</span>
          </button>
        )}
      </div>

      {/* Grid */}
      {filtered.length === 0 ? (
        <div className="py-16 text-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
          <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">{t(lang, 'noResults')}</p>
          <button
            type="button"
            onClick={resetFilters}
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg cursor-pointer"
          >
            {t(lang, 'clearFilters')}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((project) => (
            <ProjectCard
              key={project.id}
              project={project}
              lang={lang}
              onViewProject={onViewProject}
              onContactStudent={onContactStudent}
            />
          ))}
        </div>
      )}
    </div>
  );
}
