import { useEffect, useState } from 'react';
import {
  CheckCircle2,
  ShieldAlert,
  Trash2,
  Upload,
  Plus,
  Star,
  Check,
  X,
} from 'lucide-react';
import {
  Language,
  MentorRequestItem,
  ProjectItem,
  ReviewItem,
  UserProfile,
} from '../types';
import { DEPARTMENTS, SEMESTERS, t } from '../i18n';
import { apiFetch, uploadFile } from '../lib/api';
import { SmartImage } from './SmartImage';

interface DashboardViewProps {
  lang: Language;
  currentUser: UserProfile;
  availableSkills: string[];
  projects: ProjectItem[];
  onUserUpdated: (user: UserProfile) => void;
  onOpenUpload: () => void;
  onViewProject: (project: ProjectItem) => void;
  onRefreshData: () => void;
}

export function DashboardView({
  lang,
  currentUser,
  availableSkills,
  projects,
  onUserUpdated,
  onOpenUpload,
  onViewProject,
  onRefreshData,
}: DashboardViewProps) {
  const [activeTab, setActiveTab] = useState<'profile' | 'projects' | 'requests' | 'reviews'>('profile');

  // Profile form state
  const [name, setName] = useState(currentUser.name);
  const [department, setDepartment] = useState(currentUser.department);
  const [semester, setSemester] = useState(currentUser.semester);
  const [rollNo, setRollNo] = useState(currentUser.roll_no);
  const [role, setRole] = useState<'student' | 'mentor'>(
    currentUser.role === 'mentor' ? 'mentor' : 'student'
  );
  const [bio, setBio] = useState(currentUser.bio);
  const [githubUrl, setGithubUrl] = useState(currentUser.github_url);
  const [linkedinUrl, setLinkedinUrl] = useState(currentUser.linkedin_url);
  const [photo, setPhoto] = useState(currentUser.photo);
  const [skills, setSkills] = useState<string[]>(currentUser.skills);
  const [saving, setSaving] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [saveNotice, setSaveNotice] = useState('');

  // Verification code state
  const [verifyCode, setVerifyCode] = useState('4821');
  const [verifying, setVerifying] = useState(false);

  // Requests & Reviews
  const [requests, setRequests] = useState<MentorRequestItem[]>([]);
  const [reviews, setReviews] = useState<ReviewItem[]>([]);

  const myProjects = projects.filter((p) => p.user_id === currentUser.id);

  const loadDashboardExtras = async () => {
    try {
      const [reqs, revs] = await Promise.all([
        apiFetch<MentorRequestItem[]>('/api/mentor-requests'),
        apiFetch<ReviewItem[]>(`/api/reviews?user_id=${currentUser.id}`),
      ]);
      setRequests(reqs);
      setReviews(revs);
    } catch {
      // handled silently
    }
  };

  useEffect(() => {
    loadDashboardExtras();
  }, [currentUser.id]);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingPhoto(true);
    try {
      const uploaded = await uploadFile(file);
      setPhoto(uploaded.url);
    } catch (err) {
      setSaveNotice(err instanceof Error ? err.message : 'Photo upload failed');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSaveNotice('');
    try {
      const res = await apiFetch<{ user: UserProfile }>('/api/users/me', {
        method: 'PATCH',
        body: JSON.stringify({
          name,
          department,
          semester,
          roll_no: rollNo,
          role: currentUser.role === 'admin' ? 'admin' : role,
          bio,
          github_url: githubUrl,
          linkedin_url: linkedinUrl,
          photo,
          skills,
        }),
      });
      onUserUpdated(res.user);
      setSaveNotice(lang === 'bn' ? 'প্রোফাইল আপডেট হয়েছে।' : 'Profile updated successfully.');
      onRefreshData();
    } catch (err) {
      setSaveNotice(err instanceof Error ? err.message : 'Failed to save');
    } finally {
      setSaving(false);
    }
  };

  const handleVerifyProfile = async () => {
    setVerifying(true);
    try {
      const res = await apiFetch<{ user: UserProfile }>('/api/auth/verify', {
        method: 'POST',
        body: JSON.stringify({ code: verifyCode }),
      });
      onUserUpdated(res.user);
      onRefreshData();
    } catch {
      // ignore
    } finally {
      setVerifying(false);
    }
  };

  const handleDeleteProject = async (pid: number) => {
    await apiFetch(`/api/projects/${pid}`, { method: 'DELETE' });
    onRefreshData();
  };

  const handleUpdateRequest = async (id: number, status: 'accepted' | 'completed' | 'declined') => {
    await apiFetch(`/api/mentor-requests/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
    loadDashboardExtras();
  };

  const toggleSkill = (skill: string) => {
    setSkills((prev) =>
      prev.includes(skill) ? prev.filter((s) => s !== skill) : [...prev, skill]
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6">
        <div className="flex items-center gap-4">
          <SmartImage
            src={currentUser.photo}
            alt={currentUser.name}
            className="w-16 h-16 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                {currentUser.name}
              </h1>
              {currentUser.is_verified === 1 ? (
                <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 dark:text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" />
                  {t(lang, 'verifiedBadge')}
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-600 dark:text-amber-400">
                  <ShieldAlert className="w-4 h-4" />
                  {t(lang, 'unverifiedBadge')}
                </span>
              )}
            </div>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-0.5">
              {currentUser.department} · {currentUser.semester} Sem
              {currentUser.roll_no ? ` · Roll ${currentUser.roll_no}` : ''} · {currentUser.email}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onOpenUpload}
          className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{t(lang, 'uploadProject')}</span>
        </button>
      </div>

      {/* Email Verification Prompt if unverified */}
      {currentUser.is_verified === 0 && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/70 rounded-xl">
          <div className="text-xs sm:text-sm text-amber-900 dark:text-amber-200">
            <span className="font-semibold">
              {lang === 'bn' ? 'প্রোফাইল ভেরিফিকেশন:' : 'Profile Verification:'}
            </span>{' '}
            {lang === 'bn'
              ? 'আপনার স্টুডেন্ট ইমেইল ভেরিফাই করতে নিচের ৪-ডিজিট কোডটি কনফার্ম করুন।'
              : 'Enter the 4-digit campus verification code sent to your student email to unlock the Verified badge.'}
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <input
              type="text"
              value={verifyCode}
              onChange={(e) => setVerifyCode(e.target.value)}
              className="w-24 px-3 py-1.5 text-xs font-mono bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-700 rounded-lg text-slate-900 dark:text-white"
            />
            <button
              type="button"
              onClick={handleVerifyProfile}
              disabled={verifying}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg cursor-pointer"
            >
              {verifying ? '...' : lang === 'bn' ? 'ভেরিফাই করুন' : 'Verify Now'}
            </button>
          </div>
        </div>
      )}

      {/* Segmented Tabs */}
      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg w-fit border border-slate-200 dark:border-slate-700">
        {(
          [
            ['profile', lang === 'bn' ? 'প্রোফাইল ও স্কিল' : 'Profile & Skills'],
            ['projects', `${lang === 'bn' ? 'আমার প্রজেক্ট' : 'My Projects'} (${myProjects.length})`],
            ['requests', `${lang === 'bn' ? 'মেন্টর রিকোয়েস্ট' : 'Mentor Requests'} (${requests.length})`],
            ['reviews', `${lang === 'bn' ? 'রেটিং ও রিভিউ' : 'Reviews'} (${reviews.length})`],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setActiveTab(id)}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === id
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Tab 1: Profile Editor */}
      {activeTab === 'profile' && (
        <form
          onSubmit={handleSaveProfile}
          className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-6"
        >
          {saveNotice && (
            <div className="p-3 text-xs font-medium text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-lg">
              {saveNotice}
            </div>
          )}

          <div className="flex flex-col sm:flex-row sm:items-center gap-4 pb-5 border-b border-slate-100 dark:border-slate-800">
            <SmartImage
              src={photo}
              alt={name}
              className="w-20 h-20 rounded-xl object-cover border border-slate-200 dark:border-slate-700"
            />
            <div>
              <label className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-800 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg cursor-pointer">
                <Upload className="w-3.5 h-3.5" />
                <span>{uploadingPhoto ? 'Uploading...' : lang === 'bn' ? 'ছবি পরিবর্তন করুন' : 'Upload Photo'}</span>
                <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
              </label>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5">
                JPG, PNG or WebP (max 8MB)
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {lang === 'bn' ? 'পূর্ণ নাম' : 'Full Name'}
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {lang === 'bn' ? 'ডিপার্টমেন্ট' : 'Department'}
              </label>
              <select
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
              >
                {DEPARTMENTS.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {lang === 'bn' ? 'সেমিস্টার' : 'Semester'}
              </label>
              <select
                value={semester}
                onChange={(e) => setSemester(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
              >
                {[...SEMESTERS, 'Faculty'].map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {lang === 'bn' ? 'রোল নম্বর' : 'Roll No'}
              </label>
              <input
                type="text"
                value={rollNo}
                onChange={(e) => setRollNo(e.target.value)}
                className="w-full px-3.5 py-2 text-sm font-mono bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                GitHub URL
              </label>
              <input
                type="url"
                value={githubUrl}
                onChange={(e) => setGithubUrl(e.target.value)}
                placeholder="https://github.com/username"
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                LinkedIn URL
              </label>
              <input
                type="url"
                value={linkedinUrl}
                onChange={(e) => setLinkedinUrl(e.target.value)}
                placeholder="https://linkedin.com/in/username"
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {currentUser.role !== 'admin' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {lang === 'bn' ? 'অ্যাকাউন্ট ভূমিকা' : 'Community Role'}
              </label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as 'student' | 'mentor')}
                className="w-full sm:w-64 px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
              >
                <option value="student">Student</option>
                <option value="mentor">Senior Mentor (Open to guide juniors)</option>
              </select>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              {lang === 'bn' ? 'নিজের সম্পর্কে (Bio)' : 'About / Bio'}
            </label>
            <textarea
              rows={3}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
              {lang === 'bn' ? 'আপনার স্কিলসমূহ' : 'Skills'}
            </label>
            <div className="flex flex-wrap gap-1.5">
              {availableSkills.map((sk) => {
                const active = skills.includes(sk);
                return (
                  <button
                    key={sk}
                    type="button"
                    onClick={() => toggleSkill(sk)}
                    className={`px-3 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                      active
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    {sk}
                  </button>
                );
              })}
            </div>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="px-6 py-2.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
          >
            {saving
              ? lang === 'bn'
                ? 'সংরক্ষণ হচ্ছে...'
                : 'Saving...'
              : lang === 'bn'
                ? 'প্রোফাইল সংরক্ষণ করুন'
                : 'Save Profile'}
          </button>
        </form>
      )}

      {/* Tab 2: My Projects */}
      {activeTab === 'projects' && (
        <div className="space-y-4">
          {myProjects.length === 0 ? (
            <div className="py-12 text-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
              <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                {lang === 'bn' ? 'আপনি এখনো কোনো প্রজেক্ট আপলোড করেননি।' : 'You have not uploaded any projects yet.'}
              </p>
              <button
                type="button"
                onClick={onOpenUpload}
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg cursor-pointer"
              >
                {t(lang, 'uploadProject')}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {myProjects.map((proj) => (
                <div
                  key={proj.id}
                  className="flex flex-col bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden"
                >
                  <div className="aspect-[4/3] bg-slate-100 dark:bg-slate-800">
                    <SmartImage src={proj.image} alt={proj.title} className="w-full h-full object-cover" />
                  </div>
                  <div className="p-4 flex-1 flex flex-col">
                    <p className="text-xs text-blue-600 dark:text-blue-400 font-medium mb-1">
                      {proj.department} · {proj.tags.join(' · ')}
                    </p>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                      {lang === 'bn' && proj.title_bn ? proj.title_bn : proj.title}
                    </h3>
                    <div className="mt-auto pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                      <button
                        type="button"
                        onClick={() => onViewProject(proj)}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg cursor-pointer"
                      >
                        {t(lang, 'viewProject')}
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteProject(proj.id)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-lg cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>{lang === 'bn' ? 'মুছুন' : 'Delete'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Mentor Requests */}
      {activeTab === 'requests' && (
        <div className="space-y-4">
          {requests.length === 0 ? (
            <div className="py-12 text-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-sm text-slate-600 dark:text-slate-400">
              {lang === 'bn' ? 'কোনো মেন্টর রিকোয়েস্ট নেই।' : 'No mentor requests yet.'}
            </div>
          ) : (
            <div className="space-y-3">
              {requests.map((req) => {
                const isIncoming = req.mentor_id === currentUser.id;
                return (
                  <div
                    key={req.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl"
                  >
                    <div className="space-y-1">
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {isIncoming
                          ? `${lang === 'bn' ? 'জুনিয়র:' : 'From:'} ${req.junior_name} (${req.junior_department} · ${req.junior_semester})`
                          : `${lang === 'bn' ? 'সিনিয়র মেন্টর:' : 'To:'} ${req.mentor_name} (${req.mentor_department} · ${req.mentor_semester})`}
                        {' · '}
                        <span className="font-semibold capitalize text-slate-800 dark:text-slate-200">
                          Status: {req.status}
                        </span>
                      </p>
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                        {req.topic || 'Mentorship Guidance'}
                      </h3>
                      <p className="text-sm text-slate-600 dark:text-slate-300">{req.message}</p>
                    </div>

                    {isIncoming && req.status === 'pending' && (
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleUpdateRequest(req.id, 'accepted')}
                          className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Accept</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleUpdateRequest(req.id, 'declined')}
                          className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5" />
                          <span>Decline</span>
                        </button>
                      </div>
                    )}

                    {isIncoming && req.status === 'accepted' && (
                      <button
                        type="button"
                        onClick={() => handleUpdateRequest(req.id, 'completed')}
                        className="px-3 py-1.5 text-xs font-semibold text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 rounded-lg cursor-pointer shrink-0"
                      >
                        Mark Completed
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Reviews Received */}
      {activeTab === 'reviews' && (
        <div className="space-y-3">
          {reviews.length === 0 ? (
            <div className="py-12 text-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-sm text-slate-600 dark:text-slate-400">
              {lang === 'bn' ? 'এখনো কোনো রেটিং পাওয়া যায়নি।' : 'No reviews received yet.'}
            </div>
          ) : (
            reviews.map((rev) => (
              <div
                key={rev.id}
                className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-bold text-slate-900 dark:text-white">
                    {rev.reviewer_name}
                  </span>
                  <span className="inline-flex items-center gap-1 text-xs font-mono tabular-nums text-slate-700 dark:text-slate-300">
                    <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                    {rev.rating}.0
                  </span>
                </div>
                <p className="text-sm text-slate-600 dark:text-slate-300">{rev.comment}</p>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
