import { useEffect, useState } from 'react';
import {
  X,
  ExternalLink,
  FileText,
  Star,
  CheckCircle2,
  Send,
  Upload,
  Flag,
  Mail,
} from 'lucide-react';
import {
  JobItem,
  Language,
  ProjectItem,
  ReviewItem,
  UserProfile,
} from '../types';
import { DEPARTMENTS, t } from '../i18n';
import { apiFetch, uploadFile } from '../lib/api';
import { SmartImage } from './SmartImage';

/* -------------------------------------------------------------------------- */
/* 1. Project Detail & Reviews Lightbox                                       */
/* -------------------------------------------------------------------------- */
interface ProjectDetailModalProps {
  project: ProjectItem | null;
  lang: Language;
  currentUser: UserProfile | null;
  onClose: () => void;
  onContactStudent: (userId: number) => void;
  onRequireAuth: () => void;
  onRefreshProjects: () => void;
  onNotify: (msg: string) => void;
}

export function ProjectDetailModal({
  project,
  lang,
  currentUser,
  onClose,
  onContactStudent,
  onRequireAuth,
  onRefreshProjects,
  onNotify,
}: ProjectDetailModalProps) {
  const [reviews, setReviews] = useState<ReviewItem[]>([]);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [reporting, setReporting] = useState(false);
  const [reportReason, setReportReason] = useState('');

  useEffect(() => {
    if (!project) return;
    apiFetch<{ project: ProjectItem; reviews: ReviewItem[] }>(`/api/projects/${project.id}`)
      .then((res) => setReviews(res.reviews))
      .catch(() => setReviews([]));
  }, [project?.id]);

  if (!project) return null;

  const title = lang === 'bn' && project.title_bn ? project.title_bn : project.title;
  const description = lang === 'bn' && project.description_bn ? project.description_bn : project.description;

  const submitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onRequireAuth();
      return;
    }
    setSubmitting(true);
    try {
      const res = await apiFetch<{ review: ReviewItem }>('/api/reviews', {
        method: 'POST',
        body: JSON.stringify({
          project_id: project.id,
          target_user_id: project.user_id,
          rating,
          comment,
        }),
      });
      setReviews((prev) => [res.review, ...prev]);
      setComment('');
      onRefreshProjects();
      onNotify(lang === 'bn' ? 'রিভিউ যুক্ত হয়েছে!' : 'Review posted!');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to post review');
    } finally {
      setSubmitting(false);
    }
  };

  const submitReport = async () => {
    if (!currentUser) {
      onRequireAuth();
      return;
    }
    if (!reportReason.trim()) return;
    await apiFetch('/api/reports', {
      method: 'POST',
      body: JSON.stringify({
        target_type: 'project',
        target_id: project.id,
        reason: reportReason,
      }),
    });
    setReporting(false);
    setReportReason('');
    onNotify(lang === 'bn' ? 'রিপোর্ট পাঠানো হয়েছে।' : 'Report submitted to faculty admin.');
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xs border-b border-slate-200 dark:border-slate-800">
          <p className="text-xs font-medium text-blue-600 dark:text-blue-400">
            {project.department} · {project.author_semester} Sem
          </p>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="aspect-[16/9] rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-800">
            <SmartImage src={project.image} alt={title} className="w-full h-full object-cover" />
          </div>

          <div>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white leading-snug">
              {title}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
              {project.tags.join(' · ')}
            </p>
          </div>

          <p className="text-sm sm:text-base text-slate-700 dark:text-slate-300 leading-relaxed">
            {description}
          </p>

          {/* Action Links */}
          <div className="flex flex-wrap items-center gap-3">
            {project.github_link && (
              <a
                href={project.github_link}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 rounded-lg"
              >
                <span>{t(lang, 'github')}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
            {project.live_link && (
              <a
                href={project.live_link}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg"
              >
                <span>Live Demo</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
            {project.pdf_url && (
              <a
                href={project.pdf_url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 rounded-lg"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Project Documentation (PDF)</span>
              </a>
            )}
            <button
              type="button"
              onClick={() => {
                onClose();
                onContactStudent(project.user_id);
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 rounded-lg cursor-pointer"
            >
              <span>{t(lang, 'contactStudent')}</span>
            </button>
            <button
              type="button"
              onClick={() => setReporting((r) => !r)}
              className="ml-auto inline-flex items-center gap-1 px-2.5 py-2 text-xs text-slate-500 hover:text-red-600 cursor-pointer"
            >
              <Flag className="w-3.5 h-3.5" />
              <span>{t(lang, 'reportPost')}</span>
            </button>
          </div>

          {reporting && (
            <div className="p-4 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-xl space-y-3">
              <input
                type="text"
                value={reportReason}
                onChange={(e) => setReportReason(e.target.value)}
                placeholder="Reason (e.g., spam, fake link, inappropriate content)"
                className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-red-200 dark:border-red-800 rounded-lg"
              />
              <button
                type="button"
                onClick={submitReport}
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer"
              >
                Submit Report
              </button>
            </div>
          )}

          {/* Author Strip */}
          <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl">
            <div className="flex items-center gap-3">
              <SmartImage
                src={project.author_photo}
                alt={project.author_name}
                className="w-11 h-11 rounded-full object-cover"
              />
              <div>
                <div className="flex items-center gap-1.5">
                  <p className="text-sm font-bold text-slate-900 dark:text-white">
                    {project.author_name}
                  </p>
                  {project.author_verified === 1 && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  )}
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {project.author_department} · {project.author_semester} Semester
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                onClose();
                onContactStudent(project.user_id);
              }}
              className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
            >
              View Profile
            </button>
          </div>

          {/* Reviews Section */}
          <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              {t(lang, 'ratingLabel')} ({reviews.length})
            </h3>

            <form onSubmit={submitReview} className="space-y-3">
              <div className="flex items-center gap-1.5">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    className="p-1 cursor-pointer"
                    aria-label={`Rate ${star} stars`}
                  >
                    <Star
                      className={`w-5 h-5 ${
                        star <= rating
                          ? 'text-amber-500 fill-amber-500'
                          : 'text-slate-300 dark:text-slate-700'
                      }`}
                    />
                  </button>
                ))}
                <span className="text-xs font-mono text-slate-500 ml-2">{rating}.0 / 5.0</span>
              </div>

              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  required
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder={
                    lang === 'bn'
                      ? 'প্রজেক্ট সম্পর্কে আপনার মতামত লিখুন...'
                      : 'Write constructive feedback on this project...'
                  }
                  className="flex-1 px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
                />
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg whitespace-nowrap cursor-pointer"
                >
                  {t(lang, 'submitReview')}
                </button>
              </div>
            </form>

            <div className="space-y-2.5">
              {reviews.map((rev) => (
                <div
                  key={rev.id}
                  className="p-3.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-slate-900 dark:text-white">
                      {rev.reviewer_name}
                    </span>
                    <span className="inline-flex items-center gap-1 text-xs font-mono tabular-nums">
                      <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                      {rev.rating}.0
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300">
                    {rev.comment}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* 2. Upload Project Modal                                                    */
/* -------------------------------------------------------------------------- */
interface UploadProjectModalProps {
  open: boolean;
  lang: Language;
  availableSkills: string[];
  onClose: () => void;
  onSuccess: () => void;
}

export function UploadProjectModal({
  open,
  lang,
  availableSkills,
  onClose,
  onSuccess,
}: UploadProjectModalProps) {
  const [title, setTitle] = useState('');
  const [titleBn, setTitleBn] = useState('');
  const [description, setDescription] = useState('');
  const [department, setDepartment] = useState('Computer');
  const [tags, setTags] = useState<string[]>(['HTML', 'CSS', 'JavaScript']);
  const [githubLink, setGithubLink] = useState('');
  const [liveLink, setLiveLink] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [pdfUrl, setPdfUrl] = useState('');
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  if (!open) return null;

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>, type: 'image' | 'pdf') => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError('');
    try {
      const res = await uploadFile(file);
      if (type === 'image') setImageUrl(res.url);
      else setPdfUrl(res.url);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'File upload failed');
    } finally {
      setUploading(false);
    }
  };

  const toggleTag = (tag: string) => {
    setTags((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      await apiFetch('/api/projects', {
        method: 'POST',
        body: JSON.stringify({
          title,
          title_bn: titleBn,
          description,
          department,
          tags,
          github_link: githubLink,
          live_link: liveLink,
          image: imageUrl,
          pdf_url: pdfUrl,
        }),
      });
      setTitle('');
      setTitleBn('');
      setDescription('');
      setGithubLink('');
      setLiveLink('');
      setImageUrl('');
      setPdfUrl('');
      onSuccess();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not publish project');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            {t(lang, 'uploadProject')}
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg">
              {error}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Project Title (English)
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Smart Hostel Attendance System"
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                প্রজেক্টের নাম (বাংলা - ঐচ্ছিক)
              </label>
              <input
                type="text"
                value={titleBn}
                onChange={(e) => setTitleBn(e.target.value)}
                placeholder="স্মার্ট হোস্টেল হাজিরা সিস্টেম"
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Department
            </label>
            <select
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            >
              {DEPARTMENTS.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Project Description
            </label>
            <textarea
              required
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Explain what problem it solves, hardware/software stack, and key features..."
              className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Skill Tags
            </label>
            <div className="flex flex-wrap gap-1.5">
              {availableSkills.map((sk) => (
                <button
                  key={sk}
                  type="button"
                  onClick={() => toggleTag(sk)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md cursor-pointer ${
                    tags.includes(sk)
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {sk}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                GitHub Repository URL
              </label>
              <input
                type="url"
                value={githubLink}
                onChange={(e) => setGithubLink(e.target.value)}
                placeholder="https://github.com/..."
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Live Demo URL (Optional)
              </label>
              <input
                type="url"
                value={liveLink}
                onChange={(e) => setLiveLink(e.target.value)}
                placeholder="https://..."
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
            </div>
          </div>

          {/* File Uploads: Image + PDF */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <label className="flex items-center gap-2 px-3.5 py-2.5 text-xs font-medium bg-slate-50 dark:bg-slate-950 border border-dashed border-slate-300 dark:border-slate-700 rounded-lg cursor-pointer hover:border-blue-500">
              <Upload className="w-4 h-4 text-blue-600" />
              <span className="truncate">
                {imageUrl ? 'Screenshot uploaded ✓' : uploading ? 'Uploading...' : 'Upload Project Image (JPG/PNG)'}
              </span>
              <input type="file" accept="image/*" onChange={(e) => handleFile(e, 'image')} className="hidden" />
            </label>

            <label className="flex items-center gap-2 px-3.5 py-2.5 text-xs font-medium bg-slate-50 dark:bg-slate-950 border border-dashed border-slate-300 dark:border-slate-700 rounded-lg cursor-pointer hover:border-emerald-500">
              <FileText className="w-4 h-4 text-emerald-600" />
              <span className="truncate">
                {pdfUrl ? 'PDF Report attached ✓' : 'Attach PDF Report (Optional)'}
              </span>
              <input type="file" accept="application/pdf" onChange={(e) => handleFile(e, 'pdf')} className="hidden" />
            </label>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-lg cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting || uploading}
              className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-60 rounded-lg cursor-pointer"
            >
              {submitting ? 'Publishing...' : 'Publish Project'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* 3. Student Profile & Contact Modal                                         */
/* -------------------------------------------------------------------------- */
interface StudentProfileModalProps {
  userId: number | null;
  lang: Language;
  onClose: () => void;
  onRequestMentor: (mentor: UserProfile) => void;
  onViewProject: (project: ProjectItem) => void;
}

export function StudentProfileModal({
  userId,
  lang,
  onClose,
  onRequestMentor,
  onViewProject,
}: StudentProfileModalProps) {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [projects, setProjects] = useState<ProjectItem[]>([]);

  useEffect(() => {
    if (!userId) return;
    apiFetch<{ user: UserProfile; projects: ProjectItem[] }>(`/api/users/${userId}`)
      .then((res) => {
        setProfile(res.user);
        setProjects(res.projects);
      })
      .catch(() => setProfile(null));
  }, [userId]);

  if (!userId || !profile) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800">
          <span className="text-xs font-semibold text-blue-600 dark:text-blue-400">
            {profile.department} · {profile.semester} Semester
          </span>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <SmartImage
              src={profile.photo}
              alt={profile.name}
              className="w-20 h-20 rounded-xl object-cover border border-slate-200 dark:border-slate-700"
            />
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">{profile.name}</h2>
                {profile.is_verified === 1 && (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                )}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Roll: {profile.roll_no || 'N/A'} · Rating:{' '}
                {profile.avg_rating > 0 ? `${profile.avg_rating} ★` : 'New'}
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-2">
                {profile.skills.join(' · ')}
              </p>
            </div>
          </div>

          <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">{profile.bio}</p>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => {
                onClose();
                onRequestMentor(profile);
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{t(lang, 'requestMentorship')}</span>
            </button>

            <a
              href={`mailto:${profile.email}`}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded-lg"
            >
              <Mail className="w-3.5 h-3.5" />
              <span>{profile.email}</span>
            </a>

            {profile.github_url && (
              <a
                href={profile.github_url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded-lg"
              >
                <span>GitHub</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>

          {projects.length > 0 && (
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {lang === 'bn' ? 'আপলোডকৃত প্রজেক্টসমূহ' : 'Student Projects'} ({projects.length})
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {projects.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      onClose();
                      onViewProject(p);
                    }}
                    className="p-3 text-left bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 hover:border-blue-500 rounded-lg cursor-pointer"
                  >
                    <p className="text-xs font-semibold text-slate-900 dark:text-white line-clamp-1">
                      {lang === 'bn' && p.title_bn ? p.title_bn : p.title}
                    </p>
                    <p className="text-xs text-slate-500 mt-1 truncate">{p.tags.join(' · ')}</p>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* 4. Mentor Request Modal                                                    */
/* -------------------------------------------------------------------------- */
interface MentorRequestModalProps {
  mentor: UserProfile | null;
  lang: Language;
  onClose: () => void;
  onSent: () => void;
}

export function MentorRequestModal({
  mentor,
  lang,
  onClose,
  onSent,
}: MentorRequestModalProps) {
  const [topic, setTopic] = useState('');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');

  if (!mentor) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    setError('');
    try {
      await apiFetch('/api/mentor-requests', {
        method: 'POST',
        body: JSON.stringify({ mentor_id: mentor.id, topic, message }),
      });
      setTopic('');
      setMessage('');
      onSent();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to send request');
    } finally {
      setSending(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            {t(lang, 'requestMentorship')}
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-slate-600 dark:text-slate-400">
          {lang === 'bn' ? 'প্রাপক:' : 'Sending request to:'}{' '}
          <strong className="text-slate-900 dark:text-white">{mentor.name}</strong> ({mentor.department} · {mentor.semester})
        </p>

        {error && (
          <div className="p-2.5 text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              {lang === 'bn' ? 'বিষয় / প্রজেক্ট টপিক' : 'Topic / Skill'}
            </label>
            <input
              type="text"
              required
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g., React API Integration or PLC Wiring"
              className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              {lang === 'bn' ? 'বার্তা' : 'Message'}
            </label>
            <textarea
              required
              rows={3}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Briefly describe what guidance or project feedback you need..."
              className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium bg-slate-100 dark:bg-slate-800 rounded-lg cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={sending}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg cursor-pointer"
            >
              {sending ? 'Sending...' : 'Send Request'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* 5. Post Micro-Job Modal & Apply Modal                                      */
/* -------------------------------------------------------------------------- */
interface PostJobModalProps {
  open: boolean;
  lang: Language;
  onClose: () => void;
  onCreated: () => void;
}

export function PostJobModal({ open, lang, onClose, onCreated }: PostJobModalProps) {
  const [clientName, setClientName] = useState('');
  const [title, setTitle] = useState('');
  const [titleBn, setTitleBn] = useState('');
  const [department, setDepartment] = useState('Computer');
  const [budget, setBudget] = useState('৳3,000');
  const [contact, setContact] = useState('');
  const [description, setDescription] = useState('');
  const [saving, setSaving] = useState(false);

  if (!open) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await apiFetch('/api/jobs', {
        method: 'POST',
        body: JSON.stringify({
          client_name: clientName,
          title,
          title_bn: titleBn,
          department,
          budget,
          contact,
          description,
        }),
      });
      setClientName('');
      setTitle('');
      setTitleBn('');
      setContact('');
      setDescription('');
      onCreated();
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">{t(lang, 'postJob')}</h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <input
            type="text"
            required
            value={clientName}
            onChange={(e) => setClientName(e.target.value)}
            placeholder="Client / Shop / Coaching Center Name"
            className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
          />
          <input
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Task Title (e.g., Shop Website or Poster Design)"
            className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
          />
          <input
            type="text"
            value={titleBn}
            onChange={(e) => setTitleBn(e.target.value)}
            placeholder="কাজের শিরোনাম (বাংলা - ঐচ্ছিক)"
            className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
          />
          <div className="grid grid-cols-2 gap-3">
            <select
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            >
              {DEPARTMENTS.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
            <input
              type="text"
              required
              value={budget}
              onChange={(e) => setBudget(e.target.value)}
              placeholder="Budget (e.g., ৳4,500)"
              className="px-3.5 py-2 text-sm font-mono bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
          </div>
          <input
            type="text"
            required
            value={contact}
            onChange={(e) => setContact(e.target.value)}
            placeholder="Phone or Email Contact (Naogaon)"
            className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
          />
          <textarea
            required
            rows={3}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe requirements, deadline, and deliverables..."
            className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
          />

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium bg-slate-100 dark:bg-slate-800 rounded-lg cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg cursor-pointer"
            >
              {saving ? 'Posting...' : 'Post Job'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

interface ApplyJobModalProps {
  job: JobItem | null;
  lang: Language;
  onClose: () => void;
  onApplied: () => void;
}

export function ApplyJobModal({ job, lang, onClose, onApplied }: ApplyJobModalProps) {
  const [proposal, setProposal] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');

  if (!job) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    setError('');
    try {
      await apiFetch(`/api/jobs/${job.id}/apply`, {
        method: 'POST',
        body: JSON.stringify({ proposal }),
      });
      setProposal('');
      onApplied();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Application failed');
    } finally {
      setSending(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">{t(lang, 'applyNow')}</h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-slate-600 dark:text-slate-400">
          <strong className="text-slate-900 dark:text-white">{job.title}</strong> · {job.budget}
        </p>

        {error && (
          <div className="p-2.5 text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3">
          <textarea
            required
            rows={4}
            value={proposal}
            onChange={(e) => setProposal(e.target.value)}
            placeholder="Share your relevant project experience, timeline, and phone number..."
            className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg"
          />

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium bg-slate-100 dark:bg-slate-800 rounded-lg cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={sending}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg cursor-pointer"
            >
              {sending ? 'Submitting...' : 'Submit Application'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
