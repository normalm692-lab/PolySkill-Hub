export function getAuthToken(): string | null {
  return localStorage.getItem('polyskill_token');
}

export function setAuthToken(token: string | null) {
  if (token) {
    localStorage.setItem('polyskill_token', token);
  } else {
    localStorage.removeItem('polyskill_token');
  }
}

export async function apiFetch<T>(url: string, options: RequestInit = {}): Promise<T> {
  const token = getAuthToken();
  const headers: Record<string, string> = {
    ...(options.headers as Record<string, string>),
  };

  if (!(options.body instanceof FormData) && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(url, { ...options, headers });
  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data as T;
}

export async function uploadFile(file: File): Promise<{ url: string; filename: string }> {
  const formData = new FormData();
  formData.append('file', file);
  return apiFetch<{ url: string; filename: string }>('/api/upload', {
    method: 'POST',
    body: formData,
  });
}
