export type Language = 'en' | 'bn';
export type ThemeMode = 'light' | 'dark';

export type Department =
  | 'Computer'
  | 'Electrical'
  | 'Civil'
  | 'Mechanical'
  | 'Electronics'
  | 'RAC';

export type UserRole = 'student' | 'mentor' | 'admin';

export interface UserProfile {
  id: number;
  name: string;
  email: string;
  department: Department | string;
  semester: string;
  role: UserRole;
  photo: string;
  bio: string;
  github_url: string;
  linkedin_url: string;
  roll_no: string;
  is_verified: number;
  skills: string[];
  avg_rating: number;
  review_count: number;
  project_count: number;
  created_at: string;
}

export interface ProjectItem {
  id: number;
  user_id: number;
  author_name: string;
  author_photo: string;
  author_department: string;
  author_semester: string;
  author_verified: number;
  author_email?: string;
  author_github?: string;
  author_linkedin?: string;
  title: string;
  title_bn: string;
  description: string;
  description_bn: string;
  department: string;
  tags: string[];
  image: string;
  pdf_url: string;
  github_link: string;
  live_link: string;
  status: 'active' | 'flagged';
  avg_rating: number;
  review_count: number;
  created_at: string;
}

export interface MentorRequestItem {
  id: number;
  junior_id: number;
  junior_name: string;
  junior_department: string;
  junior_semester: string;
  junior_photo: string;
  mentor_id: number;
  mentor_name: string;
  mentor_department: string;
  mentor_semester: string;
  mentor_photo: string;
  topic: string;
  message: string;
  status: 'pending' | 'accepted' | 'completed' | 'declined';
  created_at: string;
}

export interface JobApplicationItem {
  id: number;
  job_id: number;
  student_id: number;
  student_name: string;
  student_department: string;
  student_semester: string;
  student_photo: string;
  proposal: string;
  status: 'pending' | 'shortlisted' | 'hired';
  created_at: string;
}

export interface JobItem {
  id: number;
  posted_by_user_id: number | null;
  client_name: string;
  title: string;
  title_bn: string;
  description: string;
  department: string;
  budget: string;
  contact: string;
  status: 'open' | 'assigned' | 'completed';
  applicant_count: number;
  applications?: JobApplicationItem[];
  created_at: string;
}

export interface ReviewItem {
  id: number;
  project_id: number | null;
  target_user_id: number | null;
  reviewer_id: number | null;
  reviewer_name: string;
  rating: number;
  comment: string;
  created_at: string;
}

export interface ReportItem {
  id: number;
  reporter_id: number | null;
  reporter_name: string;
  target_type: 'user' | 'project' | 'job';
  target_id: number;
  target_label: string;
  reason: string;
  status: 'open' | 'resolved' | 'dismissed';
  created_at: string;
}

export interface PlatformStats {
  total_projects: number;
  total_students: number;
  total_mentors: number;
  open_jobs: number;
}
