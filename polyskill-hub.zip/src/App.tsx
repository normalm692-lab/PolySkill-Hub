import { useEffect, useState } from 'react';
import {
  JobItem,
  Language,
  PlatformStats,
  ProjectItem,
  ThemeMode,
  UserProfile,
} from './types';
import { apiFetch, getAuthToken, setAuthToken } from './lib/api';
import { Header, PageView } from './components/Header';
import { WorkspaceBar } from './components/WorkspaceBar';
import { HomeView } from './components/HomeView';
import { ProjectsView } from './components/ProjectsView';
import { MentorsView } from './components/MentorsView';
import { JobsView } from './components/JobsView';
import { AuthView } from './components/AuthView';
import { DashboardView } from './components/DashboardView';
import { AdminView } from './components/AdminView';
import {
  ApplyJobModal,
  MentorRequestModal,
  PostJobModal,
  ProjectDetailModal,
  StudentProfileModal,
  UploadProjectModal,
} from './components/Modals';
import { DEPARTMENTS, t } from './i18n';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageView>('home');
  const [lang, setLang] = useState<Language>('en');
  const [theme, setTheme] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem('polyskill_theme');
    return saved === 'dark' ? 'dark' : 'light';
  });

  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [stats, setStats] = useState<PlatformStats>({
    total_projects: 0,
    total_students: 0,
    total_mentors: 0,
    open_jobs: 0,
  });
  const [projects, setProjects] = useState<ProjectItem[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [jobs, setJobs] = useState<JobItem[]>([]);
  const [skills, setSkills] = useState<string[]>([]);

  // Modal states
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);
  const [selectedStudentId, setSelectedStudentId] = useState<number | null>(null);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [mentorModalTarget, setMentorModalTarget] = useState<UserProfile | null>(null);
  const [postJobOpen, setPostJobOpen] = useState(false);
  const [applyJobTarget, setApplyJobTarget] = useState<JobItem | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('polyskill_theme', theme);
  }, [theme]);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3500);
  };

  const loadAllData = async () => {
    try {
      const [statsRes, projectsRes, usersRes, jobsRes, skillsRes] = await Promise.all([
        apiFetch<PlatformStats>('/api/stats'),
        apiFetch<ProjectItem[]>('/api/projects'),
        apiFetch<UserProfile[]>('/api/users'),
        apiFetch<JobItem[]>('/api/jobs'),
        apiFetch<{ id: number; skill_name: string }[]>('/api/skills'),
      ]);
      setStats(statsRes);
      setProjects(projectsRes);
      setUsers(usersRes);
      setJobs(jobsRes);
      setSkills(skillsRes.map((s) => s.skill_name));
    } catch {
      // handled gracefully
    }
  };

  useEffect(() => {
    loadAllData();
    if (getAuthToken()) {
      apiFetch<{ user: UserProfile }>('/api/auth/me')
        .then((res) => setCurrentUser(res.user))
        .catch(() => {
          setAuthToken(null);
          setCurrentUser(null);
        });
    }
  }, []);

  const handleOpenUpload = () => {
    if (!currentUser) {
      showToast(lang === 'bn' ? 'প্রজেক্ট আপলোড করতে লগইন করুন।' : 'Please sign in to upload a project.');
      setCurrentPage('auth');
      return;
    }
    setUploadModalOpen(true);
  };

  const handleRequestMentor = (mentor: UserProfile) => {
    if (!currentUser) {
      showToast(lang === 'bn' ? 'মেন্টর রিকোয়েস্ট পাঠাতে লগইন করুন।' : 'Please sign in to send a mentor request.');
      setCurrentPage('auth');
      return;
    }
    setMentorModalTarget(mentor);
  };

  const handlePostJob = () => {
    if (!currentUser) {
      showToast(lang === 'bn' ? 'নতুন কাজ পোস্ট করতে লগইন করুন।' : 'Please sign in to post a micro-job.');
      setCurrentPage('auth');
      return;
    }
    setPostJobOpen(true);
  };

  const handleApplyJob = (job: JobItem) => {
    if (!currentUser) {
      showToast(lang === 'bn' ? 'আবেদন করতে লগইন করুন।' : 'Please sign in to apply for this job.');
      setCurrentPage('auth');
      return;
    }
    setApplyJobTarget(job);
  };

  const handleUpdateJobStatus = async (jobId: number, status: 'open' | 'assigned' | 'completed') => {
    await apiFetch(`/api/jobs/${jobId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
    loadAllData();
  };

  const handleSignOut = () => {
    setAuthToken(null);
    setCurrentUser(null);
    setCurrentPage('home');
    showToast(lang === 'bn' ? 'সফলভাবে লগআউট হয়েছে।' : 'Signed out.');
  };

  const handleNavigate = (page: PageView) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <Header
        currentPage={currentPage}
        onNavigate={handleNavigate}
        lang={lang}
        currentUser={currentUser}
      />

      <WorkspaceBar
        currentPage={currentPage}
        lang={lang}
        onToggleLang={setLang}
        theme={theme}
        onToggleTheme={() => setTheme((prev) => (prev === 'light' ? 'dark' : 'light'))}
        currentUser={currentUser}
        onOpenUpload={handleOpenUpload}
        onNavigate={handleNavigate}
        onSignOut={handleSignOut}
      />

      <main className="flex-1">
        {currentPage === 'home' && (
          <HomeView
            lang={lang}
            stats={stats}
            projects={projects}
            students={users}
            jobs={jobs}
            currentUser={currentUser}
            onNavigate={handleNavigate}
            onViewProject={setSelectedProject}
            onSelectStudent={setSelectedStudentId}
            onOpenUpload={handleOpenUpload}
            onApplyJob={handleApplyJob}
          />
        )}

        {currentPage === 'projects' && (
          <ProjectsView
            lang={lang}
            projects={projects}
            availableSkills={skills}
            onViewProject={setSelectedProject}
            onContactStudent={setSelectedStudentId}
            onOpenUpload={handleOpenUpload}
          />
        )}

        {currentPage === 'mentors' && (
          <MentorsView
            lang={lang}
            users={users}
            onSelectStudent={setSelectedStudentId}
            onRequestMentor={handleRequestMentor}
          />
        )}

        {currentPage === 'jobs' && (
          <JobsView
            lang={lang}
            jobs={jobs}
            currentUser={currentUser}
            onPostJob={handlePostJob}
            onApplyJob={handleApplyJob}
            onUpdateJobStatus={handleUpdateJobStatus}
          />
        )}

        {currentPage === 'auth' && (
          <AuthView
            lang={lang}
            availableSkills={skills}
            onAuthSuccess={(user) => {
              setCurrentUser(user);
              setCurrentPage(user.role === 'admin' ? 'admin' : 'dashboard');
              loadAllData();
              showToast(`Welcome, ${user.name}!`);
            }}
          />
        )}

        {currentPage === 'dashboard' && currentUser && (
          <DashboardView
            lang={lang}
            currentUser={currentUser}
            availableSkills={skills}
            projects={projects}
            onUserUpdated={setCurrentUser}
            onOpenUpload={handleOpenUpload}
            onViewProject={setSelectedProject}
            onRefreshData={loadAllData}
          />
        )}

        {currentPage === 'admin' && currentUser?.role === 'admin' && (
          <AdminView lang={lang} onRefreshGlobal={loadAllData} />
        )}
      </main>

      {/* Clean Minimal Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 grid grid-cols-1 md:grid-cols-12 gap-8">
          <div className="md:col-span-6 space-y-2">
            <p className="text-base font-bold text-slate-900 dark:text-white">PolySkill Hub</p>
            <p className="text-xs font-medium text-blue-600 dark:text-blue-400">
              {t(lang, 'campusTag')} · {t(lang, 'slogan')}
            </p>
            <p className="text-xs text-slate-600 dark:text-slate-400 max-w-md leading-relaxed pt-1">
              {t(lang, 'footerDesc')}
            </p>
          </div>

          <div className="md:col-span-3 space-y-2">
            <p className="text-xs font-bold text-slate-900 dark:text-white">
              {t(lang, 'footerQuickLinks')}
            </p>
            <ul className="space-y-1.5 text-xs text-slate-600 dark:text-slate-400">
              <li>
                <button type="button" onClick={() => handleNavigate('projects')} className="hover:text-blue-600 cursor-pointer">
                  {t(lang, 'navProjects')}
                </button>
              </li>
              <li>
                <button type="button" onClick={() => handleNavigate('mentors')} className="hover:text-blue-600 cursor-pointer">
                  {t(lang, 'navMentors')}
                </button>
              </li>
              <li>
                <button type="button" onClick={() => handleNavigate('jobs')} className="hover:text-blue-600 cursor-pointer">
                  {t(lang, 'navJobs')}
                </button>
              </li>
            </ul>
          </div>

          <div className="md:col-span-3 space-y-2">
            <p className="text-xs font-bold text-slate-900 dark:text-white">
              {t(lang, 'footerDepartments')}
            </p>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              {DEPARTMENTS.join(' · ')}
            </p>
          </div>
        </div>
        <div className="border-t border-slate-100 dark:border-slate-800 py-4 px-4 sm:px-6 text-center text-xs text-slate-500 dark:text-slate-400">
          © {new Date().getFullYear()} PolySkill Hub · {t(lang, 'campusTag')}
        </div>
      </footer>

      {/* Modals */}
      <ProjectDetailModal
        project={selectedProject}
        lang={lang}
        currentUser={currentUser}
        onClose={() => setSelectedProject(null)}
        onContactStudent={setSelectedStudentId}
        onRequireAuth={() => {
          setSelectedProject(null);
          setCurrentPage('auth');
        }}
        onRefreshProjects={loadAllData}
        onNotify={showToast}
      />

      <UploadProjectModal
        open={uploadModalOpen}
        lang={lang}
        availableSkills={skills}
        onClose={() => setUploadModalOpen(false)}
        onSuccess={() => {
          loadAllData();
          showToast(lang === 'bn' ? 'প্রজেক্ট প্রকাশিত হয়েছে!' : 'Project published!');
        }}
      />

      <StudentProfileModal
        userId={selectedStudentId}
        lang={lang}
        onClose={() => setSelectedStudentId(null)}
        onRequestMentor={handleRequestMentor}
        onViewProject={setSelectedProject}
      />

      <MentorRequestModal
        mentor={mentorModalTarget}
        lang={lang}
        onClose={() => setMentorModalTarget(null)}
        onSent={() => {
          showToast(lang === 'bn' ? 'মেন্টর রিকোয়েস্ট পাঠানো হয়েছে!' : 'Mentor request sent!');
        }}
      />

      <PostJobModal
        open={postJobOpen}
        lang={lang}
        onClose={() => setPostJobOpen(false)}
        onCreated={() => {
          loadAllData();
          showToast(lang === 'bn' ? 'নতুন কাজ পোস্ট করা হয়েছে!' : 'Micro-job posted!');
        }}
      />

      <ApplyJobModal
        job={applyJobTarget}
        lang={lang}
        onClose={() => setApplyJobTarget(null)}
        onApplied={() => {
          loadAllData();
          showToast(lang === 'bn' ? 'আবেদন জমা হয়েছে!' : 'Application submitted!');
        }}
      />

      {/* Non-intrusive Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 px-4 py-2.5 text-xs font-semibold text-white bg-slate-900 dark:bg-blue-600 rounded-lg shadow-lg border border-slate-700 dark:border-blue-500">
          {toast}
        </div>
      )}
    </div>
  );
}
