import { useMemo, useState } from 'react';
import { Search, CheckCircle2, Star, Send, ExternalLink } from 'lucide-react';
import { Language, UserProfile } from '../types';
import { DEPARTMENTS, t } from '../i18n';
import { SmartImage } from './SmartImage';

interface MentorsViewProps {
  lang: Language;
  users: UserProfile[];
  onSelectStudent: (userId: number) => void;
  onRequestMentor: (mentor: UserProfile) => void;
}

export function MentorsView({
  lang,
  users,
  onSelectStudent,
  onRequestMentor,
}: MentorsViewProps) {
  const [roleFilter, setRoleFilter] = useState<'all' | 'mentor'>('mentor');
  const [deptFilter, setDeptFilter] = useState<string>('all');
  const [query, setQuery] = useState('');

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return users.filter((u) => {
      if (roleFilter === 'mentor' && u.role !== 'mentor') return false;
      if (deptFilter !== 'all' && u.department !== deptFilter) return false;
      if (q) {
        const hay = `${u.name} ${u.department} ${u.roll_no} ${u.bio} ${u.skills.join(' ')}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [users, roleFilter, deptFilter, query]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
            {t(lang, 'navMentors')}
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            {t(lang, 'topStudentsSub')}
          </p>
        </div>

        {/* Role Filter */}
        <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 self-start">
          <button
            type="button"
            onClick={() => setRoleFilter('mentor')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              roleFilter === 'mentor'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {lang === 'bn' ? 'সিনিয়র মেন্টর' : 'Senior Mentors'}
          </button>
          <button
            type="button"
            onClick={() => setRoleFilter('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              roleFilter === 'all'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {lang === 'bn' ? 'সব শিক্ষার্থী' : 'All Students'}
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t(lang, 'searchMentorsPlaceholder')}
            className="w-full pl-10 pr-4 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={() => setDeptFilter('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              deptFilter === 'all'
                ? 'bg-blue-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            {t(lang, 'allDepartments')}
          </button>
          {DEPARTMENTS.map((dept) => (
            <button
              key={dept}
              type="button"
              onClick={() => setDeptFilter(dept)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                deptFilter === dept
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {dept}
            </button>
          ))}
        </div>
      </div>

      {/* Directory Grid */}
      {filtered.length === 0 ? (
        <div className="py-16 text-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
          <p className="text-sm text-slate-600 dark:text-slate-400">{t(lang, 'noResults')}</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((person) => (
            <div
              key={person.id}
              className="flex flex-col p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl"
            >
              <div className="flex items-start gap-4 mb-4">
                <button
                  type="button"
                  onClick={() => onSelectStudent(person.id)}
                  className="shrink-0 cursor-pointer"
                >
                  <SmartImage
                    src={person.photo}
                    alt={person.name}
                    className="w-16 h-16 rounded-xl object-cover border border-slate-200 dark:border-slate-700"
                  />
                </button>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => onSelectStudent(person.id)}
                      className="text-base font-bold text-slate-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 truncate cursor-pointer text-left"
                    >
                      {person.name}
                    </button>
                    {person.is_verified === 1 && (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    )}
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    {person.department} · {person.semester} Sem
                  </p>
                  <div className="flex items-center gap-3 mt-1.5 text-xs font-mono tabular-nums text-slate-600 dark:text-slate-400">
                    <span className="inline-flex items-center gap-1 text-slate-800 dark:text-slate-200">
                      <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                      {person.avg_rating > 0 ? person.avg_rating.toFixed(1) : 'New'}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{person.project_count} Projects</span>
                  </div>
                </div>
              </div>

              <p className="text-sm text-slate-600 dark:text-slate-400 line-clamp-3 mb-4 leading-relaxed">
                {person.bio}
              </p>

              {/* Unboxed Skills */}
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-5 truncate">
                {person.skills.join(' · ') || 'Engineering Student'}
              </p>

              <div className="mt-auto pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onRequestMentor(person)}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{t(lang, 'requestMentorship')}</span>
                </button>
                <button
                  type="button"
                  onClick={() => onSelectStudent(person.id)}
                  className="inline-flex items-center justify-center gap-1 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                >
                  <span>{lang === 'bn' ? 'প্রোফাইল' : 'Profile'}</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
