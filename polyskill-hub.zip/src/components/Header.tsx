import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { Language, UserProfile } from '../types';
import { t } from '../i18n';

export type PageView = 'home' | 'projects' | 'mentors' | 'jobs' | 'dashboard' | 'admin' | 'auth';

interface HeaderProps {
  currentPage: PageView;
  onNavigate: (page: PageView) => void;
  lang: Language;
  currentUser: UserProfile | null;
}

export function Header({ currentPage, onNavigate, lang, currentUser }: HeaderProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems: { id: PageView; label: string }[] = [
    { id: 'home', label: t(lang, 'navHome') },
    { id: 'projects', label: t(lang, 'navProjects') },
    { id: 'mentors', label: t(lang, 'navMentors') },
    { id: 'jobs', label: t(lang, 'navJobs') },
  ];

  if (currentUser) {
    navItems.push({
      id: currentUser.role === 'admin' ? 'admin' : 'dashboard',
      label: currentUser.role === 'admin' ? t(lang, 'navAdmin') : t(lang, 'navDashboard'),
    });
  }

  const handleNav = (page: PageView) => {
    onNavigate(page);
    setMobileOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-950/95 backdrop-blur-sm border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <button
          type="button"
          onClick={() => handleNav('home')}
          className="text-lg font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-blue-600 rounded"
        >
          PolySkill Hub
        </button>

        {/* Zone 2: 4–5 concise single-line text links */}
        <nav aria-label="Primary" className="hidden md:flex items-center gap-7">
          {navItems.map((item) => {
            const active = currentPage === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNav(item.id)}
                className={`text-sm font-medium whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
                  active
                    ? 'border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400'
                    : 'border-transparent text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          {currentUser ? (
            <button
              type="button"
              onClick={() => handleNav(currentUser.role === 'admin' ? 'admin' : 'dashboard')}
              className="hidden md:inline-flex items-center px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {currentUser.name.split(' ')[0]}
            </button>
          ) : (
            <button
              type="button"
              onClick={() => handleNav('auth')}
              className="hidden md:inline-flex items-center px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {t(lang, 'signIn')}
            </button>
          )}

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-label="Toggle navigation menu"
            className="md:hidden p-2.5 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileOpen && (
        <div className="md:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 px-4 py-3 space-y-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => handleNav(item.id)}
              className={`block w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium cursor-pointer ${
                currentPage === item.id
                  ? 'bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-900'
              }`}
            >
              {item.label}
            </button>
          ))}
          {!currentUser && (
            <button
              type="button"
              onClick={() => handleNav('auth')}
              className="mt-2 w-full py-2.5 px-4 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg cursor-pointer"
            >
              {t(lang, 'signIn')}
            </button>
          )}
        </div>
      )}
    </header>
  );
}
