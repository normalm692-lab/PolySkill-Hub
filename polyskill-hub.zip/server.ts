import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import multer from 'multer';
import { db, initDatabase } from './server/db.ts';

initDatabase();

const app = express();
const PORT = Number(process.env.PORT || 3000);
const TOKEN_SECRET = process.env.SESSION_SECRET || 'polyskill-naogaon-dev-secret-key';

const uploadsDir = path.resolve(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

app.use(express.json({ limit: '10mb' }));
app.use('/uploads', express.static(uploadsDir));
app.use('/src/assets/images', express.static(path.resolve(process.cwd(), 'src/assets/images')));

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadsDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const safeName = `${Date.now()}-${crypto.randomBytes(6).toString('hex')}${ext}`;
    cb(null, safeName);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = [
      'image/jpeg',
      'image/png',
      'image/webp',
      'application/pdf',
    ];
    if (allowed.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Only JPG, PNG, WebP images and PDF documents are allowed.'));
    }
  },
});

interface TokenPayload {
  id: number;
  email: string;
  role: string;
  exp: number;
}

function signToken(user: { id: number; email: string; role: string }): string {
  const payload: TokenPayload = {
    id: user.id,
    email: user.email,
    role: user.role,
    exp: Date.now() + 7 * 24 * 60 * 60 * 1000,
  };
  const encoded = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', TOKEN_SECRET).update(encoded).digest('base64url');
  return `${encoded}.${sig}`;
}

function verifyToken(token: string): TokenPayload | null {
  try {
    const [encoded, sig] = token.split('.');
    if (!encoded || !sig) return null;
    const expected = crypto.createHmac('sha256', TOKEN_SECRET).update(encoded).digest('base64url');
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
    const payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as TokenPayload;
    if (payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

interface AuthedRequest extends Request {
  user?: { id: number; email: string; role: string };
}

function optionalAuth(req: AuthedRequest, _res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (authHeader?.startsWith('Bearer ')) {
    const decoded = verifyToken(authHeader.slice(7));
    if (decoded) {
      req.user = { id: decoded.id, email: decoded.email, role: decoded.role };
    }
  }
  next();
}

function requireAuth(req: AuthedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  const decoded = verifyToken(authHeader.slice(7));
  if (!decoded) {
    return res.status(401).json({ error: 'Invalid or expired session token' });
  }
  req.user = { id: decoded.id, email: decoded.email, role: decoded.role };
  next();
}

function requireAdmin(req: AuthedRequest, res: Response, next: NextFunction) {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  const dbUser = db.prepare('SELECT role FROM users WHERE id = ?').get(req.user.id) as { role: string } | undefined;
  if (!dbUser || dbUser.role !== 'admin') {
    return res.status(403).json({ error: 'Admin privileges required' });
  }
  next();
}

function hydrateUser(row: Record<string, unknown>) {
  const uid = Number(row.id);
  const skills = db
    .prepare(`
      SELECT s.skill_name FROM skills s
      JOIN user_skills us ON us.skill_id = s.id
      WHERE us.user_id = ?
      ORDER BY s.skill_name ASC
    `)
    .all(uid) as { skill_name: string }[];

  const reviewAgg = db
    .prepare(`SELECT COALESCE(AVG(rating), 0) as avg_rating, COUNT(*) as review_count FROM reviews WHERE target_user_id = ?`)
    .get(uid) as { avg_rating: number; review_count: number };

  const projAgg = db
    .prepare(`SELECT COUNT(*) as project_count FROM projects WHERE user_id = ? AND status = 'active'`)
    .get(uid) as { project_count: number };

  return {
    id: uid,
    name: row.name,
    email: row.email,
    department: row.department,
    semester: row.semester,
    role: row.role,
    photo: row.photo,
    bio: row.bio,
    github_url: row.github_url,
    linkedin_url: row.linkedin_url,
    roll_no: row.roll_no,
    is_verified: row.is_verified,
    skills: skills.map((s) => s.skill_name),
    avg_rating: Number(reviewAgg.avg_rating.toFixed(1)),
    review_count: reviewAgg.review_count,
    project_count: projAgg.project_count,
    created_at: row.created_at,
  };
}

function hydrateProject(row: Record<string, unknown>) {
  const pid = Number(row.id);
  const reviewAgg = db
    .prepare(`SELECT COALESCE(AVG(rating), 0) as avg_rating, COUNT(*) as review_count FROM reviews WHERE project_id = ?`)
    .get(pid) as { avg_rating: number; review_count: number };

  let parsedTags: string[] = [];
  try {
    parsedTags = JSON.parse(String(row.tags || '[]'));
  } catch {
    parsedTags = [];
  }

  return {
    ...row,
    tags: parsedTags,
    avg_rating: Number(reviewAgg.avg_rating.toFixed(1)),
    review_count: reviewAgg.review_count,
  };
}

// --- STATS ---
app.get('/api/stats', (_req, res) => {
  const total_projects = (db.prepare(`SELECT COUNT(*) as c FROM projects WHERE status = 'active'`).get() as { c: number }).c;
  const total_students = (db.prepare(`SELECT COUNT(*) as c FROM users WHERE role != 'admin'`).get() as { c: number }).c;
  const total_mentors = (db.prepare(`SELECT COUNT(*) as c FROM users WHERE role = 'mentor'`).get() as { c: number }).c;
  const open_jobs = (db.prepare(`SELECT COUNT(*) as c FROM jobs WHERE status = 'open'`).get() as { c: number }).c;
  res.json({ total_projects, total_students, total_mentors, open_jobs });
});

// --- SKILLS ---
app.get('/api/skills', (_req, res) => {
  const rows = db.prepare('SELECT id, skill_name FROM skills ORDER BY skill_name ASC').all();
  res.json(rows);
});

// --- AUTH ---
app.post('/api/auth/register', (req, res) => {
  const { name, email, password, department, semester, role, roll_no, skills } = req.body;
  if (!name || !email || !password || !department || !semester) {
    return res.status(400).json({ error: 'Name, email, password, department, and semester are required.' });
  }
  const normalizedEmail = String(email).trim().toLowerCase();
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(normalizedEmail);
  if (existing) {
    return res.status(409).json({ error: 'An account with this email already exists.' });
  }
  const safeRole = role === 'mentor' ? 'mentor' : 'student';
  const password_hash = bcrypt.hashSync(String(password), 10);

  const info = db
    .prepare(`
      INSERT INTO users (name, email, password_hash, department, semester, role, photo, bio, roll_no, is_verified)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
    `)
    .run(
      String(name).trim(),
      normalizedEmail,
      password_hash,
      String(department),
      String(semester),
      safeRole,
      '/src/assets/images/avatar_student_1_1794537259000.jpg',
      'Polytechnic engineering student at Naogaon Polytechnic Institute.',
      String(roll_no || '').trim()
    );

  const uid = Number(info.lastInsertRowid);
  if (Array.isArray(skills)) {
    const insertSkill = db.prepare('INSERT OR IGNORE INTO skills (skill_name) VALUES (?)');
    const getSkill = db.prepare('SELECT id FROM skills WHERE skill_name = ?');
    const linkSkill = db.prepare('INSERT OR IGNORE INTO user_skills (user_id, skill_id) VALUES (?, ?)');
    for (const s of skills) {
      const clean = String(s).trim();
      if (!clean) continue;
      insertSkill.run(clean);
      const sRow = getSkill.get(clean) as { id: number } | undefined;
      if (sRow) linkSkill.run(uid, sRow.id);
    }
  }

  const userRow = db.prepare('SELECT * FROM users WHERE id = ?').get(uid) as Record<string, unknown>;
  const token = signToken({ id: uid, email: normalizedEmail, role: safeRole });
  res.status(201).json({ token, user: hydrateUser(userRow) });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }
  const normalizedEmail = String(email).trim().toLowerCase();
  const userRow = db.prepare('SELECT * FROM users WHERE email = ?').get(normalizedEmail) as Record<string, unknown> | undefined;
  if (!userRow || !bcrypt.compareSync(String(password), String(userRow.password_hash))) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }
  const token = signToken({
    id: Number(userRow.id),
    email: String(userRow.email),
    role: String(userRow.role),
  });
  res.json({ token, user: hydrateUser(userRow) });
});

app.get('/api/auth/me', requireAuth, (req: AuthedRequest, res) => {
  const userRow = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user!.id) as Record<string, unknown> | undefined;
  if (!userRow) return res.status(404).json({ error: 'User not found' });
  res.json({ user: hydrateUser(userRow) });
});

app.post('/api/auth/verify', requireAuth, (req: AuthedRequest, res) => {
  const { code } = req.body;
  if (code && String(code).trim().length >= 4) {
    db.prepare('UPDATE users SET is_verified = 1 WHERE id = ?').run(req.user!.id);
    const userRow = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user!.id) as Record<string, unknown>;
    return res.json({ verified: true, user: hydrateUser(userRow) });
  }
  return res.status(400).json({ error: 'Please enter a valid 4+ digit verification code.' });
});

// --- FILE UPLOAD ---
app.post('/api/upload', requireAuth, (req, res) => {
  upload.single('file')(req, res, (err) => {
    if (err) {
      return res.status(400).json({ error: err.message });
    }
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    res.json({ url: `/uploads/${req.file.filename}`, filename: req.file.originalname });
  });
});

// --- USERS / STUDENTS / MENTORS ---
app.get('/api/users', (req, res) => {
  const { role, department, skill, q } = req.query;
  let sql = 'SELECT * FROM users WHERE role != \'admin\'';
  const params: unknown[] = [];

  if (role && role !== 'all') {
    sql += ' AND role = ?';
    params.push(String(role));
  }
  if (department && department !== 'all') {
    sql += ' AND department = ?';
    params.push(String(department));
  }
  if (q) {
    sql += ' AND (name LIKE ? OR bio LIKE ? OR roll_no LIKE ?)';
    const like = `%${String(q).trim()}%`;
    params.push(like, like, like);
  }
  sql += ' ORDER BY is_verified DESC, id ASC';

  const rows = db.prepare(sql).all(...params) as Record<string, unknown>[];
  let hydrated = rows.map(hydrateUser);

  if (skill && skill !== 'all') {
    const target = String(skill).toLowerCase();
    hydrated = hydrated.filter((u) => u.skills.some((s) => s.toLowerCase() === target));
  }

  res.json(hydrated);
});

app.get('/api/users/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM users WHERE id = ?').get(Number(req.params.id)) as Record<string, unknown> | undefined;
  if (!row) return res.status(404).json({ error: 'Student profile not found' });
  const projects = (db.prepare(`
    SELECT p.*, u.name as author_name, u.photo as author_photo, u.department as author_department, u.semester as author_semester, u.is_verified as author_verified
    FROM projects p JOIN users u ON u.id = p.user_id
    WHERE p.user_id = ? AND p.status = 'active'
    ORDER BY p.created_at DESC
  `).all(Number(req.params.id)) as Record<string, unknown>[]).map(hydrateProject);

  const reviews = db.prepare('SELECT * FROM reviews WHERE target_user_id = ? ORDER BY created_at DESC').all(Number(req.params.id));
  res.json({ user: hydrateUser(row), projects, reviews });
});

app.patch('/api/users/me', requireAuth, (req: AuthedRequest, res) => {
  const { name, department, semester, bio, github_url, linkedin_url, roll_no, photo, role, skills } = req.body;
  const current = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user!.id) as Record<string, unknown>;
  if (!current) return res.status(404).json({ error: 'User not found' });

  const nextRole = current.role === 'admin' ? 'admin' : (role === 'mentor' ? 'mentor' : (role === 'student' ? 'student' : String(current.role)));

  db.prepare(`
    UPDATE users SET
      name = ?,
      department = ?,
      semester = ?,
      bio = ?,
      github_url = ?,
      linkedin_url = ?,
      roll_no = ?,
      photo = ?,
      role = ?
    WHERE id = ?
  `).run(
    name !== undefined ? String(name).trim() : String(current.name),
    department !== undefined ? String(department) : String(current.department),
    semester !== undefined ? String(semester) : String(current.semester),
    bio !== undefined ? String(bio) : String(current.bio),
    github_url !== undefined ? String(github_url).trim() : String(current.github_url),
    linkedin_url !== undefined ? String(linkedin_url).trim() : String(current.linkedin_url),
    roll_no !== undefined ? String(roll_no).trim() : String(current.roll_no),
    photo !== undefined ? String(photo) : String(current.photo),
    nextRole,
    req.user!.id
  );

  if (Array.isArray(skills)) {
    db.prepare('DELETE FROM user_skills WHERE user_id = ?').run(req.user!.id);
    const insertSkill = db.prepare('INSERT OR IGNORE INTO skills (skill_name) VALUES (?)');
    const getSkill = db.prepare('SELECT id FROM skills WHERE skill_name = ?');
    const linkSkill = db.prepare('INSERT OR IGNORE INTO user_skills (user_id, skill_id) VALUES (?, ?)');
    for (const s of skills) {
      const clean = String(s).trim();
      if (!clean) continue;
      insertSkill.run(clean);
      const sRow = getSkill.get(clean) as { id: number } | undefined;
      if (sRow) linkSkill.run(req.user!.id, sRow.id);
    }
  }

  const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user!.id) as Record<string, unknown>;
  res.json({ user: hydrateUser(updated) });
});

// --- PROJECTS ---
app.get('/api/projects', (req, res) => {
  const { department, skill, q, user_id } = req.query;
  let sql = `
    SELECT p.*, u.name as author_name, u.photo as author_photo, u.department as author_department,
           u.semester as author_semester, u.is_verified as author_verified, u.email as author_email,
           u.github_url as author_github, u.linkedin_url as author_linkedin
    FROM projects p
    JOIN users u ON u.id = p.user_id
    WHERE p.status = 'active'
  `;
  const params: unknown[] = [];

  if (department && department !== 'all') {
    sql += ' AND p.department = ?';
    params.push(String(department));
  }
  if (user_id) {
    sql += ' AND p.user_id = ?';
    params.push(Number(user_id));
  }
  if (q) {
    sql += ' AND (p.title LIKE ? OR p.title_bn LIKE ? OR p.description LIKE ? OR u.name LIKE ?)';
    const like = `%${String(q).trim()}%`;
    params.push(like, like, like, like);
  }
  sql += ' ORDER BY p.id DESC';

  const rows = db.prepare(sql).all(...params) as Record<string, unknown>[];
  let hydrated = rows.map(hydrateProject);

  if (skill && skill !== 'all') {
    const target = String(skill).toLowerCase();
    hydrated = hydrated.filter((p) => p.tags.some((t: string) => t.toLowerCase() === target));
  }

  res.json(hydrated);
});

app.get('/api/projects/:id', (req, res) => {
  const row = db.prepare(`
    SELECT p.*, u.name as author_name, u.photo as author_photo, u.department as author_department,
           u.semester as author_semester, u.is_verified as author_verified, u.email as author_email,
           u.github_url as author_github, u.linkedin_url as author_linkedin
    FROM projects p
    JOIN users u ON u.id = p.user_id
    WHERE p.id = ?
  `).get(Number(req.params.id)) as Record<string, unknown> | undefined;

  if (!row) return res.status(404).json({ error: 'Project not found' });
  const reviews = db.prepare('SELECT * FROM reviews WHERE project_id = ? ORDER BY created_at DESC').all(Number(req.params.id));
  res.json({ project: hydrateProject(row), reviews });
});

app.post('/api/projects', requireAuth, (req: AuthedRequest, res) => {
  const { title, title_bn, description, description_bn, department, tags, image, pdf_url, github_link, live_link } = req.body;
  if (!title || !description || !department) {
    return res.status(400).json({ error: 'Title, description, and department are required.' });
  }
  const cleanTags = Array.isArray(tags) ? tags.map((t) => String(t).trim()).filter(Boolean) : [];
  const defaultImg = department === 'Electrical'
    ? '/src/assets/images/proj_plc_automation_1794537258681.jpg'
    : department === 'Civil'
      ? '/src/assets/images/proj_civil_cad_1794537258517.jpg'
      : department === 'Mechanical'
        ? '/src/assets/images/proj_mechanical_cnc_1794537259454.jpg'
        : '/src/assets/images/proj_web_erp_1794537256820.jpg';

  const info = db.prepare(`
    INSERT INTO projects (user_id, title, title_bn, description, description_bn, department, tags, image, pdf_url, github_link, live_link)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    req.user!.id,
    String(title).trim(),
    String(title_bn || '').trim(),
    String(description).trim(),
    String(description_bn || '').trim(),
    String(department),
    JSON.stringify(cleanTags),
    image ? String(image) : defaultImg,
    String(pdf_url || '').trim(),
    String(github_link || '').trim(),
    String(live_link || '').trim()
  );

  const created = db.prepare(`
    SELECT p.*, u.name as author_name, u.photo as author_photo, u.department as author_department,
           u.semester as author_semester, u.is_verified as author_verified, u.email as author_email,
           u.github_url as author_github, u.linkedin_url as author_linkedin
    FROM projects p JOIN users u ON u.id = p.user_id WHERE p.id = ?
  `).get(Number(info.lastInsertRowid)) as Record<string, unknown>;

  res.status(201).json({ project: hydrateProject(created) });
});

app.delete('/api/projects/:id', requireAuth, (req: AuthedRequest, res) => {
  const pid = Number(req.params.id);
  const proj = db.prepare('SELECT user_id FROM projects WHERE id = ?').get(pid) as { user_id: number } | undefined;
  if (!proj) return res.status(404).json({ error: 'Project not found' });
  if (proj.user_id !== req.user!.id && req.user!.role !== 'admin') {
    return res.status(403).json({ error: 'You can only delete your own project.' });
  }
  db.prepare('DELETE FROM projects WHERE id = ?').run(pid);
  res.json({ deleted: true });
});

// --- MENTOR REQUESTS ---
app.get('/api/mentor-requests', requireAuth, (req: AuthedRequest, res) => {
  const rows = db.prepare(`
    SELECT mr.*,
           ju.name as junior_name, ju.department as junior_department, ju.semester as junior_semester, ju.photo as junior_photo,
           mu.name as mentor_name, mu.department as mentor_department, mu.semester as mentor_semester, mu.photo as mentor_photo
    FROM mentor_requests mr
    JOIN users ju ON ju.id = mr.junior_id
    JOIN users mu ON mu.id = mr.mentor_id
    WHERE mr.junior_id = ? OR mr.mentor_id = ?
    ORDER BY mr.id DESC
  `).all(req.user!.id, req.user!.id);
  res.json(rows);
});

app.post('/api/mentor-requests', requireAuth, (req: AuthedRequest, res) => {
  const { mentor_id, topic, message } = req.body;
  if (!mentor_id || !message) {
    return res.status(400).json({ error: 'Mentor ID and message are required.' });
  }
  if (Number(mentor_id) === req.user!.id) {
    return res.status(400).json({ error: 'You cannot send a mentor request to yourself.' });
  }
  const mentor = db.prepare('SELECT id FROM users WHERE id = ?').get(Number(mentor_id));
  if (!mentor) return res.status(404).json({ error: 'Mentor not found' });

  const info = db.prepare(`
    INSERT INTO mentor_requests (junior_id, mentor_id, topic, message, status)
    VALUES (?, ?, ?, ?, 'pending')
  `).run(req.user!.id, Number(mentor_id), String(topic || 'General Guidance').trim(), String(message).trim());

  const created = db.prepare(`
    SELECT mr.*,
           ju.name as junior_name, ju.department as junior_department, ju.semester as junior_semester, ju.photo as junior_photo,
           mu.name as mentor_name, mu.department as mentor_department, mu.semester as mentor_semester, mu.photo as mentor_photo
    FROM mentor_requests mr
    JOIN users ju ON ju.id = mr.junior_id
    JOIN users mu ON mu.id = mr.mentor_id
    WHERE mr.id = ?
  `).get(Number(info.lastInsertRowid));

  res.status(201).json({ request: created });
});

app.patch('/api/mentor-requests/:id', requireAuth, (req: AuthedRequest, res) => {
  const id = Number(req.params.id);
  const { status } = req.body;
  if (!['accepted', 'completed', 'declined'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status update' });
  }
  const row = db.prepare('SELECT * FROM mentor_requests WHERE id = ?').get(id) as { mentor_id: number; junior_id: number } | undefined;
  if (!row) return res.status(404).json({ error: 'Mentor request not found' });
  if (row.mentor_id !== req.user!.id && req.user!.role !== 'admin') {
    return res.status(403).json({ error: 'Only the assigned mentor can update this request status.' });
  }
  db.prepare('UPDATE mentor_requests SET status = ? WHERE id = ?').run(status, id);
  res.json({ updated: true, status });
});

// --- MINI JOBS ---
app.get('/api/jobs', optionalAuth, (req: AuthedRequest, res) => {
  const { department, status } = req.query;
  let sql = 'SELECT * FROM jobs WHERE 1=1';
  const params: unknown[] = [];

  if (department && department !== 'all') {
    sql += ' AND department = ?';
    params.push(String(department));
  }
  if (status && status !== 'all') {
    sql += ' AND status = ?';
    params.push(String(status));
  }
  sql += ' ORDER BY id DESC';

  const rows = db.prepare(sql).all(...params) as Record<string, unknown>[];
  const enriched = rows.map((job) => {
    const jid = Number(job.id);
    const countRow = db.prepare('SELECT COUNT(*) as c FROM job_applications WHERE job_id = ?').get(jid) as { c: number };
    let applications: unknown[] = [];
    if (req.user && (job.posted_by_user_id === req.user.id || req.user.role === 'admin')) {
      applications = db.prepare(`
        SELECT ja.*, u.name as student_name, u.department as student_department, u.semester as student_semester, u.photo as student_photo
        FROM job_applications ja JOIN users u ON u.id = ja.student_id
        WHERE ja.job_id = ?
        ORDER BY ja.id DESC
      `).all(jid);
    }
    return { ...job, applicant_count: countRow.c, applications };
  });

  res.json(enriched);
});

app.post('/api/jobs', requireAuth, (req: AuthedRequest, res) => {
  const { client_name, title, title_bn, description, department, budget, contact } = req.body;
  if (!client_name || !title || !description || !budget || !contact) {
    return res.status(400).json({ error: 'Client name, title, description, budget, and contact are required.' });
  }
  const info = db.prepare(`
    INSERT INTO jobs (posted_by_user_id, client_name, title, title_bn, description, department, budget, contact, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open')
  `).run(
    req.user!.id,
    String(client_name).trim(),
    String(title).trim(),
    String(title_bn || '').trim(),
    String(description).trim(),
    String(department || 'Computer'),
    String(budget).trim(),
    String(contact).trim()
  );

  const created = db.prepare('SELECT * FROM jobs WHERE id = ?').get(Number(info.lastInsertRowid)) as Record<string, unknown>;
  res.status(201).json({ job: { ...created, applicant_count: 0, applications: [] } });
});

app.post('/api/jobs/:id/apply', requireAuth, (req: AuthedRequest, res) => {
  const jid = Number(req.params.id);
  const { proposal } = req.body;
  if (!proposal) return res.status(400).json({ error: 'Please provide a short proposal or contact note.' });

  const job = db.prepare('SELECT * FROM jobs WHERE id = ?').get(jid);
  if (!job) return res.status(404).json({ error: 'Job not found' });

  const existing = db.prepare('SELECT id FROM job_applications WHERE job_id = ? AND student_id = ?').get(jid, req.user!.id);
  if (existing) return res.status(409).json({ error: 'You have already applied for this micro-job.' });

  db.prepare('INSERT INTO job_applications (job_id, student_id, proposal) VALUES (?, ?, ?)').run(jid, req.user!.id, String(proposal).trim());
  res.status(201).json({ applied: true });
});

app.patch('/api/jobs/:id/status', requireAuth, (req: AuthedRequest, res) => {
  const jid = Number(req.params.id);
  const { status } = req.body;
  if (!['open', 'assigned', 'completed'].includes(status)) {
    return res.status(400).json({ error: 'Invalid job status' });
  }
  const job = db.prepare('SELECT posted_by_user_id FROM jobs WHERE id = ?').get(jid) as { posted_by_user_id: number } | undefined;
  if (!job) return res.status(404).json({ error: 'Job not found' });
  if (job.posted_by_user_id !== req.user!.id && req.user!.role !== 'admin') {
    return res.status(403).json({ error: 'Only the job poster or admin can update status.' });
  }
  db.prepare('UPDATE jobs SET status = ? WHERE id = ?').run(status, jid);
  res.json({ updated: true, status });
});

// --- REVIEWS ---
app.get('/api/reviews', (req, res) => {
  const { project_id, user_id } = req.query;
  if (project_id) {
    return res.json(db.prepare('SELECT * FROM reviews WHERE project_id = ? ORDER BY id DESC').all(Number(project_id)));
  }
  if (user_id) {
    return res.json(db.prepare('SELECT * FROM reviews WHERE target_user_id = ? ORDER BY id DESC').all(Number(user_id)));
  }
  res.json(db.prepare('SELECT * FROM reviews ORDER BY id DESC LIMIT 30').all());
});

app.post('/api/reviews', requireAuth, (req: AuthedRequest, res) => {
  const { project_id, target_user_id, rating, comment } = req.body;
  const numericRating = Number(rating);
  if (!numericRating || numericRating < 1 || numericRating > 5 || !comment) {
    return res.status(400).json({ error: 'Rating (1-5) and comment are required.' });
  }
  const reviewer = db.prepare('SELECT name FROM users WHERE id = ?').get(req.user!.id) as { name: string };
  let resolvedTargetUserId = target_user_id ? Number(target_user_id) : null;

  if (project_id && !resolvedTargetUserId) {
    const proj = db.prepare('SELECT user_id FROM projects WHERE id = ?').get(Number(project_id)) as { user_id: number } | undefined;
    if (proj) resolvedTargetUserId = proj.user_id;
  }

  const info = db.prepare(`
    INSERT INTO reviews (project_id, target_user_id, reviewer_id, reviewer_name, rating, comment)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(
    project_id ? Number(project_id) : null,
    resolvedTargetUserId,
    req.user!.id,
    reviewer.name,
    numericRating,
    String(comment).trim()
  );

  const created = db.prepare('SELECT * FROM reviews WHERE id = ?').get(Number(info.lastInsertRowid));
  res.status(201).json({ review: created });
});

// --- REPORTS & ADMIN PANEL ---
app.post('/api/reports', requireAuth, (req: AuthedRequest, res) => {
  const { target_type, target_id, reason } = req.body;
  if (!['user', 'project', 'job'].includes(target_type) || !target_id || !reason) {
    return res.status(400).json({ error: 'Valid target_type, target_id, and reason are required.' });
  }
  db.prepare(`
    INSERT INTO reports (reporter_id, target_type, target_id, reason, status)
    VALUES (?, ?, ?, ?, 'open')
  `).run(req.user!.id, target_type, Number(target_id), String(reason).trim());

  res.status(201).json({ reported: true });
});

app.get('/api/admin/overview', requireAuth, requireAdmin, (_req, res) => {
  const users = (db.prepare('SELECT * FROM users ORDER BY id DESC').all() as Record<string, unknown>[]).map(hydrateUser);
  const projects = (db.prepare(`
    SELECT p.*, u.name as author_name, u.photo as author_photo, u.department as author_department,
           u.semester as author_semester, u.is_verified as author_verified
    FROM projects p JOIN users u ON u.id = p.user_id ORDER BY p.id DESC
  `).all() as Record<string, unknown>[]).map(hydrateProject);
  const jobs = db.prepare('SELECT * FROM jobs ORDER BY id DESC').all();
  const rawReports = db.prepare(`
    SELECT r.*, COALESCE(u.name, 'Anonymous') as reporter_name
    FROM reports r LEFT JOIN users u ON u.id = r.reporter_id
    ORDER BY r.id DESC
  `).all() as Record<string, unknown>[];

  const reports = rawReports.map((r) => {
    let target_label = `#${r.target_id}`;
    if (r.target_type === 'project') {
      const p = db.prepare('SELECT title FROM projects WHERE id = ?').get(Number(r.target_id)) as { title: string } | undefined;
      if (p) target_label = p.title;
    } else if (r.target_type === 'user') {
      const u = db.prepare('SELECT name FROM users WHERE id = ?').get(Number(r.target_id)) as { name: string } | undefined;
      if (u) target_label = u.name;
    } else if (r.target_type === 'job') {
      const j = db.prepare('SELECT title FROM jobs WHERE id = ?').get(Number(r.target_id)) as { title: string } | undefined;
      if (j) target_label = j.title;
    }
    return { ...r, target_label };
  });

  res.json({ users, projects, jobs, reports });
});

app.patch('/api/admin/users/:id/verify', requireAuth, requireAdmin, (req, res) => {
  const uid = Number(req.params.id);
  const { is_verified } = req.body;
  db.prepare('UPDATE users SET is_verified = ? WHERE id = ?').run(is_verified ? 1 : 0, uid);
  res.json({ updated: true });
});

app.delete('/api/admin/users/:id', requireAuth, requireAdmin, (req: AuthedRequest, res) => {
  const uid = Number(req.params.id);
  if (uid === req.user!.id) return res.status(400).json({ error: 'Cannot delete the active admin account.' });
  db.prepare('DELETE FROM users WHERE id = ?').run(uid);
  res.json({ deleted: true });
});

app.patch('/api/admin/projects/:id/status', requireAuth, requireAdmin, (req, res) => {
  const pid = Number(req.params.id);
  const { status } = req.body;
  if (!['active', 'flagged'].includes(status)) return res.status(400).json({ error: 'Invalid status' });
  db.prepare('UPDATE projects SET status = ? WHERE id = ?').run(status, pid);
  res.json({ updated: true });
});

app.delete('/api/admin/jobs/:id', requireAuth, requireAdmin, (req, res) => {
  db.prepare('DELETE FROM jobs WHERE id = ?').run(Number(req.params.id));
  res.json({ deleted: true });
});

app.patch('/api/admin/reports/:id', requireAuth, requireAdmin, (req, res) => {
  const { status } = req.body;
  if (!['open', 'resolved', 'dismissed'].includes(status)) return res.status(400).json({ error: 'Invalid status' });
  db.prepare('UPDATE reports SET status = ? WHERE id = ?').run(status, Number(req.params.id));
  res.json({ updated: true });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`PolySkill Hub running on http://localhost:${PORT}`);
  });
}

startServer();
