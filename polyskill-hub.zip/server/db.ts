import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import path from 'path';

const dbPath = path.resolve(process.cwd(), 'polyskill.db');
export const db = new Database(dbPath);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      department TEXT NOT NULL,
      semester TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'student',
      photo TEXT NOT NULL DEFAULT '',
      bio TEXT NOT NULL DEFAULT '',
      github_url TEXT NOT NULL DEFAULT '',
      linkedin_url TEXT NOT NULL DEFAULT '',
      roll_no TEXT NOT NULL DEFAULT '',
      is_verified INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS skills (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      skill_name TEXT UNIQUE NOT NULL
    );

    CREATE TABLE IF NOT EXISTS user_skills (
      user_id INTEGER NOT NULL,
      skill_id INTEGER NOT NULL,
      PRIMARY KEY (user_id, skill_id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS projects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      title_bn TEXT NOT NULL DEFAULT '',
      description TEXT NOT NULL,
      description_bn TEXT NOT NULL DEFAULT '',
      department TEXT NOT NULL,
      tags TEXT NOT NULL DEFAULT '[]',
      image TEXT NOT NULL DEFAULT '',
      pdf_url TEXT NOT NULL DEFAULT '',
      github_link TEXT NOT NULL DEFAULT '',
      live_link TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS mentor_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      junior_id INTEGER NOT NULL,
      mentor_id INTEGER NOT NULL,
      topic TEXT NOT NULL DEFAULT '',
      message TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (junior_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (mentor_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS jobs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      posted_by_user_id INTEGER,
      client_name TEXT NOT NULL,
      title TEXT NOT NULL,
      title_bn TEXT NOT NULL DEFAULT '',
      description TEXT NOT NULL,
      department TEXT NOT NULL DEFAULT 'Computer',
      budget TEXT NOT NULL,
      contact TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'open',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (posted_by_user_id) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS job_applications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      job_id INTEGER NOT NULL,
      student_id INTEGER NOT NULL,
      proposal TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(job_id, student_id),
      FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
      FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id INTEGER,
      target_user_id INTEGER,
      reviewer_id INTEGER,
      reviewer_name TEXT NOT NULL,
      rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
      comment TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
      FOREIGN KEY (target_user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (reviewer_id) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS reports (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      reporter_id INTEGER,
      target_type TEXT NOT NULL,
      target_id INTEGER NOT NULL,
      reason TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'open',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE SET NULL
    );
  `);

  const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get() as { count: number };
  if (userCount.count === 0) {
    seedDatabase();
  }
}

function seedDatabase() {
  const defaultSkills = [
    'HTML', 'CSS', 'JavaScript', 'PHP', 'Laravel', 'React',
    'Python', 'AutoCAD', 'PLC', 'MySQL', 'Node.js', 'Tailwind CSS',
    'Arduino', 'SolidWorks', 'Revit', 'Figma'
  ];

  const insertSkill = db.prepare('INSERT OR IGNORE INTO skills (skill_name) VALUES (?)');
  for (const skill of defaultSkills) {
    insertSkill.run(skill);
  }

  const getSkillId = (name: string) => {
    const row = db.prepare('SELECT id FROM skills WHERE skill_name = ?').get(name) as { id: number } | undefined;
    return row?.id;
  };

  const insertUser = db.prepare(`
    INSERT INTO users (name, email, password_hash, department, semester, role, photo, bio, github_url, linkedin_url, roll_no, is_verified)
    VALUES (@name, @email, @password_hash, @department, @semester, @role, @photo, @bio, @github_url, @linkedin_url, @roll_no, @is_verified)
  `);

  const passStudent = bcrypt.hashSync('student123', 10);
  const passMentor = bcrypt.hashSync('mentor123', 10);
  const passAdmin = bcrypt.hashSync('admin123', 10);

  const users = [
    {
      name: 'Tanvir Ahmed',
      email: 'tanvir@naogaonpoly.edu.bd',
      password_hash: passMentor,
      department: 'Computer',
      semester: '7th',
      role: 'mentor',
      photo: '/src/assets/images/avatar_student_3_1794537259716.jpg',
      bio: 'Full-stack web developer & senior mentor at Naogaon Polytechnic Computer Club. Helping juniors build production Laravel and React projects.',
      github_url: 'https://github.com/tanvir-npi',
      linkedin_url: 'https://linkedin.com/in/tanvir-npi',
      roll_no: '642108',
      is_verified: 1,
      skills: ['React', 'Node.js', 'PHP', 'Laravel', 'MySQL', 'Tailwind CSS']
    },
    {
      name: 'Nusrat Jahan Mim',
      email: 'nusrat@naogaonpoly.edu.bd',
      password_hash: passMentor,
      department: 'Electrical',
      semester: '8th',
      role: 'mentor',
      photo: '/src/assets/images/avatar_student_2_1794537259614.jpg',
      bio: 'Industrial PLC automation & embedded systems enthusiast. Guiding 2nd–5th semester Electrical students on lab hardware and circuit design.',
      github_url: 'https://github.com/nusrat-eee-npi',
      linkedin_url: 'https://linkedin.com/in/nusrat-npi',
      roll_no: '618304',
      is_verified: 1,
      skills: ['PLC', 'Arduino', 'AutoCAD', 'Python']
    },
    {
      name: 'Md. Rafiqul Islam',
      email: 'rafiq@naogaonpoly.edu.bd',
      password_hash: passStudent,
      department: 'Computer',
      semester: '4th',
      role: 'student',
      photo: '/src/assets/images/avatar_student_1_1794537259000.jpg',
      bio: 'Passionate about frontend development and building helpful digital tools for local businesses in Naogaon.',
      github_url: 'https://github.com/rafiq-dev-npi',
      linkedin_url: 'https://linkedin.com/in/rafiq-npi',
      roll_no: '734219',
      is_verified: 1,
      skills: ['HTML', 'CSS', 'JavaScript', 'React', 'Tailwind CSS']
    },
    {
      name: 'Mahmudul Hasan',
      email: 'mahmud@naogaonpoly.edu.bd',
      password_hash: passMentor,
      department: 'Civil',
      semester: '7th',
      role: 'mentor',
      photo: '/src/assets/images/avatar_student_1_1794537259000.jpg',
      bio: 'Structural drafting & 3D architectural visualization specialist using AutoCAD and Revit for multi-story residential buildings.',
      github_url: 'https://github.com/mahmud-civil-npi',
      linkedin_url: 'https://linkedin.com/in/mahmud-civil',
      roll_no: '625112',
      is_verified: 1,
      skills: ['AutoCAD', 'Revit']
    },
    {
      name: 'Sadia Afrin',
      email: 'sadia@naogaonpoly.edu.bd',
      password_hash: passStudent,
      department: 'Mechanical',
      semester: '6th',
      role: 'student',
      photo: '/src/assets/images/avatar_student_2_1794537259614.jpg',
      bio: 'CAD/CAM prototyping and desktop CNC robotics builder from Mechanical Technology department.',
      github_url: 'https://github.com/sadia-mech-npi',
      linkedin_url: 'https://linkedin.com/in/sadia-mech',
      roll_no: '671045',
      is_verified: 1,
      skills: ['SolidWorks', 'AutoCAD', 'Arduino', 'Python']
    },
    {
      name: 'Engr. Kamrul Hasan',
      email: 'admin@naogaonpoly.edu.bd',
      password_hash: passAdmin,
      department: 'Computer',
      semester: 'Faculty',
      role: 'admin',
      photo: '/src/assets/images/avatar_student_3_1794537259716.jpg',
      bio: 'Instructor & Innovation Coordinator, Naogaon Polytechnic Institute. Reviewing student portfolios and ensuring community quality.',
      github_url: 'https://github.com/npi-innovation',
      linkedin_url: 'https://linkedin.com/in/kamrul-npi',
      roll_no: 'FAC-101',
      is_verified: 1,
      skills: ['PHP', 'Laravel', 'Python', 'MySQL']
    }
  ];

  const insertUserSkill = db.prepare('INSERT OR IGNORE INTO user_skills (user_id, skill_id) VALUES (?, ?)');
  const userIds: number[] = [];

  for (const u of users) {
    const info = insertUser.run({
      name: u.name,
      email: u.email,
      password_hash: u.password_hash,
      department: u.department,
      semester: u.semester,
      role: u.role,
      photo: u.photo,
      bio: u.bio,
      github_url: u.github_url,
      linkedin_url: u.linkedin_url,
      roll_no: u.roll_no,
      is_verified: u.is_verified,
    });
    const uid = Number(info.lastInsertRowid);
    userIds.push(uid);
    for (const sName of u.skills) {
      const sid = getSkillId(sName);
      if (sid) insertUserSkill.run(uid, sid);
    }
  }

  const insertProject = db.prepare(`
    INSERT INTO projects (user_id, title, title_bn, description, description_bn, department, tags, image, pdf_url, github_link, live_link, status)
    VALUES (@user_id, @title, @title_bn, @description, @description_bn, @department, @tags, @image, @pdf_url, @github_link, @live_link, 'active')
  `);

  const projects = [
    {
      user_id: userIds[0],
      title: 'Naogaon Polytechnic Student ERP & Notice Portal',
      title_bn: 'নওগাঁ পলিটেকনিক স্টুডেন্ট ইআরপি ও নোটিশ পোর্টাল',
      description: 'A full-stack campus management portal enabling semester attendance tracking, digital class routines, exam result lookup, and department notice broadcasts for 1,200+ diploma students.',
      description_bn: 'ডিপ্লোমা শিক্ষার্থীদের উপস্থিতি, ক্লাস রুটিন, পরীক্ষার ফলাফল এবং ডিপার্টমেন্ট ভিত্তিক নোটিশ দেখার পূর্ণাঙ্গ ওয়েব সিস্টেম।',
      department: 'Computer',
      tags: JSON.stringify(['React', 'Node.js', 'Tailwind CSS', 'MySQL']),
      image: '/src/assets/images/proj_web_erp_1794537256820.jpg',
      pdf_url: '',
      github_link: 'https://github.com/tanvir-npi/poly-erp-portal',
      live_link: 'https://poly-erp-demo.vercel.app'
    },
    {
      user_id: userIds[1],
      title: 'Industrial 3-Phase PLC Motor Protection & Control Trainer',
      title_bn: 'ইন্ডাস্ট্রিয়াল থ্রি-ফেজ পিএলসি মোটর কন্ট্রোল ট্রেইনার',
      description: 'Automated star-delta starter and overload fault protection system programmed in ladder logic with real-time phase voltage monitoring and emergency interlock indicators.',
      description_bn: 'ল্যাডার লজিক ব্যবহার করে স্বয়ংক্রিয় স্টার-ডেল্টা স্টার্টার ও ওভারলোড প্রোটেকশন সিস্টেমসহ রিয়াল-টাইম ভোল্টেজ মনিটরিং।',
      department: 'Electrical',
      tags: JSON.stringify(['PLC', 'Arduino', 'AutoCAD']),
      image: '/src/assets/images/proj_plc_automation_1794537258681.jpg',
      pdf_url: '',
      github_link: 'https://github.com/nusrat-eee-npi/plc-motor-trainer',
      live_link: ''
    },
    {
      user_id: userIds[3],
      title: '6-Story Earthquake-Resistant Academic Building CAD Model',
      title_bn: '৬-তলা ভূমিকম্প-সহনীয় একাডেমিক ভবনের অটোক্যাড মডেল',
      description: 'Complete structural floor plan, column layout, footing schedule, and BNBC wind/seismic load estimation modeled in AutoCAD 2D/3D and Revit.',
      description_bn: 'বিএনবিসি কোড অনুসরণ করে ৬-তলা ভবনের ফ্লোর প্ল্যান, কলাম লেআউট ও থ্রিডি স্ট্রাকচারাল ডিজাইন।',
      department: 'Civil',
      tags: JSON.stringify(['AutoCAD', 'Revit']),
      image: '/src/assets/images/proj_civil_cad_1794537258517.jpg',
      pdf_url: '',
      github_link: 'https://github.com/mahmud-civil-npi/bnbc-cad-building',
      live_link: ''
    },
    {
      user_id: userIds[4],
      title: '3-Axis Desktop CNC Plotter & Pick-and-Place Arm',
      title_bn: '৩-অ্যাক্সিস ডেস্কটপ সিএনসি ও রোবোটিক আর্ম প্রোটোটাইপ',
      description: 'Custom aluminum extrusion CNC frame driven by NEMA-17 stepper motors, GRBL firmware, and a synchronized mechanical gripper designed in SolidWorks.',
      description_bn: 'সলিডওয়ার্কসে ডিজাইনকৃত অ্যালুমিনিয়াম ফ্রেম ও স্টেপার মোটর চালিত ডেস্কটপ সিএনসি এবং রোবোটিক আর্ম।',
      department: 'Mechanical',
      tags: JSON.stringify(['SolidWorks', 'Arduino', 'Python']),
      image: '/src/assets/images/proj_mechanical_cnc_1794537259454.jpg',
      pdf_url: '',
      github_link: 'https://github.com/sadia-mech-npi/desktop-cnc-arm',
      live_link: ''
    },
    {
      user_id: userIds[2],
      title: 'Local Coaching Center Attendance & Fee Receipt App',
      title_bn: 'লোকাল কোচিং সেন্টার হাজিরা ও ফি রসিদ ওয়েব অ্যাপ',
      description: 'Lightweight web app built for Naogaon coaching centers to manage student batch enrollment, monthly tuition receipts, and SMS-ready due summaries.',
      description_bn: 'নওগাঁর স্থানীয় কোচিং সেন্টারগুলোর ব্যাচ ব্যবস্থাপনা ও মাসিক ফি রসিদ তৈরির ওয়েব অ্যাপ্লিকেশন।',
      department: 'Computer',
      tags: JSON.stringify(['HTML', 'CSS', 'JavaScript', 'PHP', 'Laravel']),
      image: '/src/assets/images/proj_web_erp_1794537256820.jpg',
      pdf_url: '',
      github_link: 'https://github.com/rafiq-dev-npi/coaching-fee-tracker',
      live_link: 'https://coaching-tracker-demo.netlify.app'
    },
    {
      user_id: userIds[1],
      title: 'Smart Solar Irrigation Pump Controller for Barind Farms',
      title_bn: 'বরেন্দ্র অঞ্চলের জন্য স্মার্ট সোলার সেচ পাম্প কন্ট্রোলার',
      description: 'Soil moisture and solar MPPT current controller engineered to automate rural crop irrigation efficiently in Naogaon.',
      description_bn: 'মাটির আর্দ্রতা ও সৌরশক্তি পর্যবেক্ষণ করে স্বয়ংক্রিয়ভাবে কৃষি সেচ পাম্প নিয়ন্ত্রণের ইলেকট্রিক্যাল সিস্টেম।',
      department: 'Electrical',
      tags: JSON.stringify(['Arduino', 'PLC', 'Python']),
      image: '/src/assets/images/proj_plc_automation_1794537258681.jpg',
      pdf_url: '',
      github_link: 'https://github.com/nusrat-eee-npi/solar-irrigation-iot',
      live_link: ''
    }
  ];

  const projectIds: number[] = [];
  for (const p of projects) {
    const info = insertProject.run(p);
    projectIds.push(Number(info.lastInsertRowid));
  }

  const insertJob = db.prepare(`
    INSERT INTO jobs (posted_by_user_id, client_name, title, title_bn, description, department, budget, contact, status)
    VALUES (@posted_by_user_id, @client_name, @title, @title_bn, @description, @department, @budget, @contact, @status)
  `);

  const jobs = [
    {
      posted_by_user_id: userIds[0],
      client_name: 'Srijon Coaching Center, Naogaon',
      title: 'Student Admission & Result Portal Website',
      title_bn: 'কোচিং সেন্টারের ভর্তি ও রেজাল্ট ওয়েবসাইট তৈরি',
      description: 'Need a fast responsive 5-page website with online admission form and PDF routine download for our SSC/Polytechnic coaching batches.',
      department: 'Computer',
      budget: '৳8,500',
      contact: '01712-458910 (Kazi Bari More)',
      status: 'open'
    },
    {
      posted_by_user_id: userIds[2],
      client_name: 'Barendra Agro & Seeds Store',
      title: 'Product Catalog & WhatsApp Order Page',
      title_bn: 'দোকানের পণ্য তালিকা ও অনলাইন অর্ডার পেজ',
      description: 'Looking for a student developer to build a clean mobile-friendly catalog page showing 40+ seed & fertilizer items with direct order link.',
      department: 'Computer',
      budget: '৳5,000',
      contact: '01819-332211 (Main Road, Naogaon)',
      status: 'open'
    },
    {
      posted_by_user_id: userIds[3],
      client_name: 'Al-Madina Builders Ltd.',
      title: '2D Ground Floor Plan Drafting in AutoCAD',
      title_bn: 'আবাসিক ভবনের অটোক্যাড ২ডি ফ্লোর প্ল্যান ড্রাফটিং',
      description: 'Convert hand-sketched 4-katha residential plot layout into clean layered AutoCAD DWG and printable PDF sheet.',
      department: 'Civil',
      budget: '৳3,500',
      contact: 'almadina.naogaon@gmail.com',
      status: 'open'
    },
    {
      posted_by_user_id: userIds[4],
      client_name: 'Naogaon Digital Press & Stationery',
      title: 'Admission Campaign Posters & Inventory Data Entry',
      title_bn: 'পোস্টার ডিজাইন ও মাসিক ইনভেন্টরি ডেটা এন্ট্রি',
      description: 'Design 4 print-ready social/banner posters and enter 350 stationery items into an organized spreadsheet.',
      department: 'Computer',
      budget: '৳2,500',
      contact: '01911-778899 (Chawkdevpara)',
      status: 'open'
    }
  ];

  for (const j of jobs) {
    insertJob.run(j);
  }

  const insertRequest = db.prepare(`
    INSERT INTO mentor_requests (junior_id, mentor_id, topic, message, status)
    VALUES (?, ?, ?, ?, ?)
  `);
  insertRequest.run(
    userIds[2],
    userIds[0],
    'Laravel + React REST API Architecture',
    'Assalamu Alaikum Tanvir bhai, I am in 4th semester Computer. Need guidance connecting my React frontend to a PHP/Laravel backend for my semester project.',
    'accepted'
  );
  insertRequest.run(
    userIds[4],
    userIds[1],
    'Stepper Motor Driver & Relay Wiring',
    'Apu, could you review our CNC limit-switch relay wiring diagram before we power up the 24V supply?',
    'pending'
  );

  const insertReview = db.prepare(`
    INSERT INTO reviews (project_id, target_user_id, reviewer_id, reviewer_name, rating, comment)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  insertReview.run(projectIds[0], userIds[0], userIds[2], 'Md. Rafiqul Islam', 5, 'Clean codebase and super helpful notice board layout for our department!');
  insertReview.run(projectIds[0], userIds[0], userIds[5], 'Engr. Kamrul Hasan', 5, 'Excellent semester capstone execution. Well-structured database schema.');
  insertReview.run(projectIds[1], userIds[1], userIds[4], 'Sadia Afrin', 5, 'Very neat PLC wiring and clear fault indicator logic.');
  insertReview.run(projectIds[2], userIds[3], userIds[5], 'Engr. Kamrul Hasan', 5, 'Accurate BNBC column spacing and crisp CAD layer discipline.');
  insertReview.run(projectIds[4], userIds[2], userIds[0], 'Tanvir Ahmed', 4, 'Great practical solution for local coaching centers. Keep improving validation!');
}
