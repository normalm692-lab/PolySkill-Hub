import { useEffect, useState } from 'react';
import { CheckCircle2, ShieldOff, Trash2, Flag } from 'lucide-react';
import { JobItem, Language, ProjectItem, ReportItem, UserProfile } from '../types';
import { apiFetch } from '../lib/api';

interface AdminViewProps {
  lang: Language;
  onRefreshGlobal: () => void;
}

interface AdminOverview {
  users: UserProfile[];
  projects: ProjectItem[];
  jobs: JobItem[];
  reports: ReportItem[];
}

export function AdminView({ lang, onRefreshGlobal }: AdminViewProps) {
  const [data, setData] = useState<AdminOverview | null>(null);
  const [tab, setTab] = useState<'users' | 'projects' | 'reports' | 'jobs'>('users');
  const [error, setError] = useState('');

  const loadOverview = async () => {
    try {
      const res = await apiFetch<AdminOverview>('/api/admin/overview');
      setData(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load admin overview');
    }
  };

  useEffect(() => {
    loadOverview();
  }, []);

  const toggleVerify = async (u: UserProfile) => {
    await apiFetch(`/api/admin/users/${u.id}/verify`, {
      method: 'PATCH',
      body: JSON.stringify({ is_verified: u.is_verified === 0 }),
    });
    await loadOverview();
    onRefreshGlobal();
  };

  const deleteUser = async (uid: number) => {
    await apiFetch(`/api/admin/users/${uid}`, { method: 'DELETE' });
    await loadOverview();
    onRefreshGlobal();
  };

  const toggleProjectFlag = async (p: ProjectItem) => {
    await apiFetch(`/api/admin/projects/${p.id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status: p.status === 'active' ? 'flagged' : 'active' }),
    });
    await loadOverview();
    onRefreshGlobal();
  };

  const deleteProject = async (pid: number) => {
    await apiFetch(`/api/projects/${pid}`, { method: 'DELETE' });
    await loadOverview();
    onRefreshGlobal();
  };

  const resolveReport = async (rid: number, status: 'resolved' | 'dismissed') => {
    await apiFetch(`/api/admin/reports/${rid}`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
    await loadOverview();
  };

  const deleteJob = async (jid: number) => {
    await apiFetch(`/api/admin/jobs/${jid}`, { method: 'DELETE' });
    await loadOverview();
    onRefreshGlobal();
  };

  if (error) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="p-4 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 rounded-xl text-sm text-red-700 dark:text-red-300">
          {error}
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 text-sm text-slate-500">
        Loading Admin Console...
      </div>
    );
  }

  const openReports = data.reports.filter((r) => r.status === 'open').length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
          {lang === 'bn' ? 'অ্যাডমিন ও ফ্যাকাল্টি মডারেশন প্যানেল' : 'Admin & Faculty Moderation Panel'}
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
          {lang === 'bn'
            ? 'শিক্ষার্থীর প্রোফাইল ভেরিফাই, ভুয়া একাউন্ট ও স্প্যাম পোস্ট অপসারণ এবং রিপোর্ট পরিচালনা করুন।'
            : 'Verify student profiles, remove fake accounts or spam projects, and resolve community reports.'}
        </p>
      </div>

      {/* KPI Summary Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 border-y border-slate-200 dark:border-slate-800 py-5">
        <div>
          <p className="text-2xl font-extrabold font-mono tabular-nums text-slate-900 dark:text-white">
            {data.users.length}
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Total Users</p>
        </div>
        <div>
          <p className="text-2xl font-extrabold font-mono tabular-nums text-slate-900 dark:text-white">
            {data.projects.length}
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Uploaded Projects</p>
        </div>
        <div>
          <p className="text-2xl font-extrabold font-mono tabular-nums text-blue-600 dark:text-blue-400">
            {data.jobs.length}
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Micro-Jobs</p>
        </div>
        <div>
          <p className="text-2xl font-extrabold font-mono tabular-nums text-amber-600 dark:text-amber-400">
            {openReports}
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Open Reports</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg w-fit border border-slate-200 dark:border-slate-700">
        {(
          [
            ['users', `Users (${data.users.length})`],
            ['projects', `Projects (${data.projects.length})`],
            ['reports', `Reports (${data.reports.length})`],
            ['jobs', `Jobs (${data.jobs.length})`],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              tab === id
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Users Table */}
      {tab === 'users' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
                <th className="py-3 px-4 font-semibold">Name & Email</th>
                <th className="py-3 px-4 font-semibold">Department</th>
                <th className="py-3 px-4 font-semibold">Role</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {data.users.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="py-3 px-4">
                    <p className="font-semibold text-slate-900 dark:text-white">{u.name}</p>
                    <p className="text-xs text-slate-500 font-mono">{u.email}</p>
                  </td>
                  <td className="py-3 px-4 text-xs text-slate-600 dark:text-slate-300">
                    {u.department} · {u.semester}
                  </td>
                  <td className="py-3 px-4 text-xs capitalize text-slate-700 dark:text-slate-300">
                    {u.role}
                  </td>
                  <td className="py-3 px-4 text-xs">
                    {u.is_verified === 1 ? (
                      <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Verified
                      </span>
                    ) : (
                      <span className="text-amber-600 dark:text-amber-400 font-medium">
                        Unverified
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right space-x-2 whitespace-nowrap">
                    <button
                      type="button"
                      onClick={() => toggleVerify(u)}
                      className="px-2.5 py-1 text-xs font-medium bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded cursor-pointer"
                    >
                      {u.is_verified === 1 ? 'Unverify' : 'Verify'}
                    </button>
                    {u.role !== 'admin' && (
                      <button
                        type="button"
                        onClick={() => deleteUser(u.id)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 rounded cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        Remove
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Projects Table */}
      {tab === 'projects' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
                <th className="py-3 px-4 font-semibold">Project Title</th>
                <th className="py-3 px-4 font-semibold">Author</th>
                <th className="py-3 px-4 font-semibold">Department</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {data.projects.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="py-3 px-4 font-semibold text-slate-900 dark:text-white">
                    {p.title}
                  </td>
                  <td className="py-3 px-4 text-xs text-slate-600 dark:text-slate-300">
                    {p.author_name}
                  </td>
                  <td className="py-3 px-4 text-xs text-slate-600 dark:text-slate-300">
                    {p.department}
                  </td>
                  <td className="py-3 px-4 text-xs">
                    {p.status === 'active' ? (
                      <span className="text-emerald-700 dark:text-emerald-400 font-medium">Active</span>
                    ) : (
                      <span className="text-red-600 dark:text-red-400 font-medium">Flagged / Hidden</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right space-x-2 whitespace-nowrap">
                    <button
                      type="button"
                      onClick={() => toggleProjectFlag(p)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded cursor-pointer"
                    >
                      <ShieldOff className="w-3.5 h-3.5" />
                      {p.status === 'active' ? 'Hide / Flag' : 'Restore'}
                    </button>
                    <button
                      type="button"
                      onClick={() => deleteProject(p.id)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 rounded cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Reports Table */}
      {tab === 'reports' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          {data.reports.length === 0 ? (
            <p className="text-sm text-slate-500 dark:text-slate-400 text-center py-8">
              No community moderation reports submitted.
            </p>
          ) : (
            <div className="space-y-3">
              {data.reports.map((r) => (
                <div
                  key={r.id}
                  className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg"
                >
                  <div>
                    <p className="text-xs text-slate-500 flex items-center gap-1.5">
                      <Flag className="w-3.5 h-3.5 text-amber-500" />
                      <span className="uppercase font-semibold">{r.target_type}</span>
                      <span>·</span>
                      <span>{r.target_label}</span>
                      <span>·</span>
                      <span>Reported by {r.reporter_name}</span>
                    </p>
                    <p className="text-sm text-slate-900 dark:text-white mt-1">{r.reason}</p>
                    <p className="text-xs text-slate-500 mt-1 capitalize">Status: {r.status}</p>
                  </div>
                  {r.status === 'open' && (
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => resolveReport(r.id, 'resolved')}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg cursor-pointer"
                      >
                        Resolve
                      </button>
                      <button
                        type="button"
                        onClick={() => resolveReport(r.id, 'dismissed')}
                        className="px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
                      >
                        Dismiss
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Jobs Table */}
      {tab === 'jobs' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
                <th className="py-3 px-4 font-semibold">Job Title</th>
                <th className="py-3 px-4 font-semibold">Client</th>
                <th className="py-3 px-4 font-semibold">Budget</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {data.jobs.map((j) => (
                <tr key={j.id}>
                  <td className="py-3 px-4 font-semibold text-slate-900 dark:text-white">
                    {j.title}
                  </td>
                  <td className="py-3 px-4 text-xs text-slate-600 dark:text-slate-300">
                    {j.client_name}
                  </td>
                  <td className="py-3 px-4 text-xs font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
                    {j.budget}
                  </td>
                  <td className="py-3 px-4 text-xs capitalize text-slate-600 dark:text-slate-300">
                    {j.status}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      type="button"
                      onClick={() => deleteJob(j.id)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 rounded cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Remove
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
