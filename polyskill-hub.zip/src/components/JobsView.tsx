import { useMemo, useState } from 'react';
import { Briefcase, Plus, CheckCircle, Clock, Users } from 'lucide-react';
import { JobItem, Language, UserProfile } from '../types';
import { DEPARTMENTS, t } from '../i18n';

interface JobsViewProps {
  lang: Language;
  jobs: JobItem[];
  currentUser: UserProfile | null;
  onPostJob: () => void;
  onApplyJob: (job: JobItem) => void;
  onUpdateJobStatus: (jobId: number, status: 'open' | 'assigned' | 'completed') => void;
}

export function JobsView({
  lang,
  jobs,
  currentUser,
  onPostJob,
  onApplyJob,
  onUpdateJobStatus,
}: JobsViewProps) {
  const [deptFilter, setDeptFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filtered = useMemo(() => {
    return jobs.filter((j) => {
      if (deptFilter !== 'all' && j.department !== deptFilter) return false;
      if (statusFilter !== 'all' && j.status !== statusFilter) return false;
      return true;
    });
  }, [jobs, deptFilter, statusFilter]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
            {t(lang, 'localJobsTitle')}
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            {t(lang, 'localJobsSub')}
          </p>
        </div>

        <button
          type="button"
          onClick={onPostJob}
          className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{t(lang, 'postJob')}</span>
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={() => setDeptFilter('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              deptFilter === 'all'
                ? 'bg-blue-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            {t(lang, 'allDepartments')}
          </button>
          {DEPARTMENTS.map((dept) => (
            <button
              key={dept}
              type="button"
              onClick={() => setDeptFilter(dept)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                deptFilter === dept
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
              }`}
            >
              {dept}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
          {(['all', 'open', 'completed'] as const).map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors capitalize whitespace-nowrap shrink-0 cursor-pointer ${
                statusFilter === st
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Job Cards */}
      {filtered.length === 0 ? (
        <div className="py-16 text-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
          <p className="text-sm text-slate-600 dark:text-slate-400">{t(lang, 'noResults')}</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((job) => {
            const jTitle = lang === 'bn' && job.title_bn ? job.title_bn : job.title;
            const isOwnerOrAdmin =
              currentUser &&
              (currentUser.id === job.posted_by_user_id || currentUser.role === 'admin');

            return (
              <article
                key={job.id}
                className="flex flex-col p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl"
              >
                <div className="flex items-start justify-between gap-4 mb-2">
                  <div className="min-w-0">
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {job.client_name} · {job.department}
                    </p>
                    <h2 className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">
                      {jTitle}
                    </h2>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="font-mono tabular-nums text-base font-extrabold text-emerald-700 dark:text-emerald-400">
                      {job.budget}
                    </p>
                    <p className="inline-flex items-center gap-1 text-xs font-medium mt-0.5 text-slate-600 dark:text-slate-400">
                      {job.status === 'open' ? (
                        <>
                          <Clock className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                          <span>Open</span>
                        </>
                      ) : (
                        <>
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                          <span className="capitalize">{job.status}</span>
                        </>
                      )}
                    </p>
                  </div>
                </div>

                <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-5">
                  {job.description}
                </p>

                <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 dark:text-slate-400 mb-4">
                  <span className="inline-flex items-center gap-1.5">
                    <Briefcase className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                    {job.contact}
                  </span>
                  <span className="inline-flex items-center gap-1.5 font-mono tabular-nums">
                    <Users className="w-3.5 h-3.5" />
                    {job.applicant_count} {lang === 'bn' ? 'আবেদন' : 'applicants'}
                  </span>
                </div>

                {/* Owner / Admin Applicant Preview */}
                {isOwnerOrAdmin && job.applications && job.applications.length > 0 && (
                  <div className="mb-4 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
                    <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                      {lang === 'bn' ? 'আবেদনকারী শিক্ষার্থী:' : 'Student Applicants:'}
                    </p>
                    {job.applications.map((app) => (
                      <div
                        key={app.id}
                        className="text-xs p-2.5 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800"
                      >
                        <p className="font-semibold text-slate-900 dark:text-white">
                          {app.student_name} · {app.student_department} ({app.student_semester})
                        </p>
                        <p className="text-slate-600 dark:text-slate-400 mt-1">{app.proposal}</p>
                      </div>
                    ))}
                  </div>
                )}

                <div className="mt-auto pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
                  {job.status === 'open' ? (
                    <button
                      type="button"
                      onClick={() => onApplyJob(job)}
                      className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                    >
                      {t(lang, 'applyNow')}
                    </button>
                  ) : (
                    <span className="text-xs font-medium text-emerald-700 dark:text-emerald-400">
                      {lang === 'bn' ? 'কাজ সম্পন্ন হয়েছে' : 'Completed'}
                    </span>
                  )}

                  {isOwnerOrAdmin && (
                    <button
                      type="button"
                      onClick={() =>
                        onUpdateJobStatus(job.id, job.status === 'open' ? 'completed' : 'open')
                      }
                      className="px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                    >
                      {job.status === 'open'
                        ? lang === 'bn'
                          ? 'সম্পন্ন মার্ক করুন'
                          : 'Mark Completed'
                        : lang === 'bn'
                          ? 'পুনরায় খুলুন'
                          : 'Reopen'}
                    </button>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
