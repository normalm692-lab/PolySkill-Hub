import { Star, ExternalLink, MessageSquare, CheckCircle2 } from 'lucide-react';
import { Language, ProjectItem } from '../types';
import { SmartImage } from './SmartImage';
import { t } from '../i18n';

interface ProjectCardProps {
  project: ProjectItem;
  lang: Language;
  onViewProject: (project: ProjectItem) => void;
  onContactStudent: (userId: number) => void;
}

export function ProjectCard({
  project,
  lang,
  onViewProject,
  onContactStudent,
}: ProjectCardProps) {
  const displayTitle = lang === 'bn' && project.title_bn ? project.title_bn : project.title;
  const displayDesc = lang === 'bn' && project.description_bn ? project.description_bn : project.description;

  return (
    <article className="group flex flex-col bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden hover:border-blue-400 dark:hover:border-blue-600 transition-colors">
      {/* Thumbnail */}
      <button
        type="button"
        onClick={() => onViewProject(project)}
        className="relative aspect-[4/3] w-full overflow-hidden bg-slate-100 dark:bg-slate-800 cursor-pointer text-left"
      >
        <SmartImage
          src={project.image}
          alt={displayTitle}
          fallbackTitle={displayTitle}
          className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-200"
        />
      </button>

      {/* Content */}
      <div className="flex-1 flex flex-col p-5">
        {/* Unboxed Metadata Line (Zero-Pill Rule) */}
        <div className="flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400 mb-2">
          <div className="flex items-center gap-1.5 truncate">
            <span className="font-medium text-blue-700 dark:text-blue-400">{project.department}</span>
            <span aria-hidden="true">·</span>
            <span>{project.author_semester} Sem</span>
          </div>
          <div className="flex items-center gap-1 shrink-0 font-mono tabular-nums text-slate-700 dark:text-slate-300">
            <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
            <span>{project.avg_rating > 0 ? project.avg_rating.toFixed(1) : 'New'}</span>
            {project.review_count > 0 && (
              <span className="text-slate-400">({project.review_count})</span>
            )}
          </div>
        </div>

        <h3 className="text-base font-bold text-slate-900 dark:text-white leading-snug mb-2 line-clamp-2">
          <button
            type="button"
            onClick={() => onViewProject(project)}
            className="text-left hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer"
          >
            {displayTitle}
          </button>
        </h3>

        <p className="text-sm text-slate-600 dark:text-slate-400 line-clamp-2 mb-3 leading-relaxed">
          {displayDesc}
        </p>

        {/* Unboxed Skill Tags */}
        {project.tags.length > 0 && (
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 truncate">
            {project.tags.join(' · ')}
          </p>
        )}

        {/* Author Row */}
        <div className="mt-auto pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2 mb-4">
          <button
            type="button"
            onClick={() => onContactStudent(project.user_id)}
            className="flex items-center gap-2.5 min-w-0 text-left group/author cursor-pointer"
          >
            <SmartImage
              src={project.author_photo}
              alt={project.author_name}
              className="w-7 h-7 rounded-full object-cover shrink-0 border border-slate-200 dark:border-slate-700"
            />
            <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate group-hover/author:text-blue-600 dark:group-hover/author:text-blue-400">
              {project.author_name}
            </span>
            {project.author_verified === 1 && (
              <CheckCircle2
                className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0"
                aria-label="Verified student"
              />
            )}
          </button>
        </div>

        {/* Requested 3 Card Action Buttons: View Project, GitHub, Contact Student */}
        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => onViewProject(project)}
            className="px-2.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors text-center whitespace-nowrap cursor-pointer"
          >
            {t(lang, 'viewProject')}
          </button>

          {project.github_link ? (
            <a
              href={project.github_link}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-1 px-2.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap"
            >
              <span>{t(lang, 'github')}</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          ) : (
            <button
              type="button"
              onClick={() => onViewProject(project)}
              className="px-2.5 py-2 text-xs font-medium text-slate-400 dark:text-slate-500 bg-slate-50 dark:bg-slate-800/50 rounded-lg cursor-not-allowed whitespace-nowrap"
              disabled
            >
              {t(lang, 'github')}
            </button>
          )}

          <button
            type="button"
            onClick={() => onContactStudent(project.user_id)}
            className="inline-flex items-center justify-center gap-1 px-2 py-2 text-xs font-medium text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 rounded-lg transition-colors whitespace-nowrap truncate cursor-pointer"
          >
            <MessageSquare className="w-3 h-3 shrink-0" />
            <span className="truncate">{lang === 'bn' ? 'যোগাযোগ' : 'Contact'}</span>
          </button>
        </div>
      </div>
    </article>
  );
}
